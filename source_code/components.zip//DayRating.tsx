import React, { useState } from 'react';
import { FeatureExplainer } from './FeatureExplainer';

const dayRatings = {
  1: { emoji: '😞', label: 'Bad', color: 'text-red-500' },
  2: { emoji: '😕', label: 'Meh', color: 'text-orange-500' },
  3: { emoji: '😐', label: 'Okay', color: 'text-yellow-500' },
  4: { emoji: '🙂', label: 'Good', color: 'text-green-500' },
  5: { emoji: '😊', label: 'Great', color: 'text-green-600' }
};

interface DayRatingProps {
  value: number | null;
  onChange: (value: number) => void;
}

export function DayRating({ value, onChange }: DayRatingProps) {

  return (
    <div className="w-full max-w-md mx-auto space-y-4">
      <div className="text-center">
        <div className="flex items-center justify-center gap-2 mb-3">
          <h3 className="text-lg text-muted-foreground">
            How has your day been?
          </h3>
          <FeatureExplainer 
            title="Day Rating"
            description="Rate your overall day from 1-5. This helps you see the bigger picture beyond just your current mood, capturing how your entire day went."
          />
        </div>
      </div>

      {/* Rating buttons */}
      <div className="flex justify-between gap-2">
        {Object.entries(dayRatings).map(([rating, data]) => {
          const ratingNum = parseInt(rating);
          const isSelected = value === ratingNum;
          
          return (
            <button
              key={rating}
              onClick={() => onChange(ratingNum)}
              className={`flex flex-col items-center p-3 rounded-lg border-2 transition-all duration-200 hover:scale-105 ${
                isSelected 
                  ? 'border-primary bg-primary/10 shadow-md' 
                  : 'border-border hover:border-primary/50'
              }`}
            >
              <div className={`text-2xl mb-1 ${isSelected ? data.color : ''}`}>
                {data.emoji}
              </div>
              <div className="text-xs text-center">
                <div className={`mb-1 ${isSelected ? 'text-primary' : 'text-muted-foreground'}`}>
                  {rating}
                </div>
                <div className={`${isSelected ? 'text-foreground' : 'text-muted-foreground'}`}>
                  {data.label}
                </div>
              </div>
            </button>
          );
        })}
      </div>

      {/* Selected rating display */}
      {value && (
        <div className="text-center p-4 bg-secondary/50 rounded-lg">
          <p className="text-sm text-muted-foreground">
            You rated your day: <span className="text-foreground">{value}/5 - {dayRatings[value as keyof typeof dayRatings].label}</span>
          </p>
        </div>
      )}
    </div>
  );
}