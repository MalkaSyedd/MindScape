import React, { useState } from 'react';
import { Textarea } from './ui/textarea';
import { NavigationMenu } from './NavigationMenu';
import { ArrowLeft } from 'lucide-react';
import { FeatureExplainer } from './FeatureExplainer';

const moodLabels = {
  1: 'Very Sad', 2: 'Sad', 3: 'Down', 4: 'Neutral', 5: 'Calm',
  6: 'Good', 7: 'Happy', 8: 'Very Happy', 9: 'Excited', 10: 'Amazing'
};

const dayLabels = {
  1: 'Bad', 2: 'Meh', 3: 'Okay', 4: 'Good', 5: 'Great'
};

const journalPrompts = [
  // Daily Reflection & Experiences
  "What was the highlight of your day?",
  "What challenged you today and how did you handle it?",
  "What made you smile today?",
  "What lesson did you learn today?",
  "What would you like to remember about today?",
  "What surprised you most about today?",
  "What moment today made you feel most alive?",
  "What small victory did you achieve today?",
  "What would you do differently if you could relive today?",
  "What was the most meaningful conversation you had today?",
  
  // Gratitude & Appreciation
  "What are you grateful for right now?",
  "Who made a positive impact on your day?",
  "What simple pleasure brought you joy today?",
  "What aspect of your life do you appreciate most right now?",
  "What skill or ability are you thankful to have?",
  "What in nature are you grateful for today?",
  "What memory are you thankful for?",
  "What challenge are you grateful for because it helped you grow?",
  "What act of kindness did you witness or receive today?",
  "What comfort or luxury in your life do you often take for granted?",
  
  // Emotions & Feelings
  "What thoughts or feelings are on your mind?",
  "What would you tell a friend who felt the same way you do today?",
  "How did your emotions change throughout the day?",
  "What emotion did you experience most strongly today?",
  "What helped you feel more peaceful today?",
  "When did you feel most confident today?",
  "What triggered stress or anxiety for you today, and how did you cope?",
  "What made you feel proud of yourself recently?",
  "How are you feeling about your current life direction?",
  "What emotion do you wish you could experience more often?",
  
  // Self-Care & Wellness
  "How did you take care of yourself today?",
  "What does your body need right now?",
  "What activity makes you feel most energized?",
  "How well did you sleep last night, and how did it affect your day?",
  "What healthy habit are you proud of maintaining?",
  "What self-care practice would benefit you most right now?",
  "How did you nourish your mind today?",
  "What physical activity brought you joy recently?",
  "How did you honor your boundaries today?",
  "What makes you feel most relaxed and at peace?",
  
  // Goals & Aspirations
  "What are you looking forward to tomorrow?",
  "What goal are you most excited to work towards?",
  "What small step can you take tomorrow toward a bigger dream?",
  "What progress did you make on your goals today?",
  "What new skill would you love to develop?",
  "What dream have you been putting off that deserves attention?",
  "What would success look like for you in the next month?",
  "What habit would make the biggest positive impact on your life?",
  "What fear is holding you back from something you want?",
  "What would you attempt if you knew you couldn't fail?",
  
  // Relationships & Connections
  "Who do you miss and why?",
  "What relationship in your life brings you the most joy?",
  "How did you show love or kindness to someone today?",
  "What quality do you most admire in your closest friend?",
  "Who has influenced you positively this year?",
  "What conversation have you been avoiding that you need to have?",
  "How did you connect with others today?",
  "What would you like to tell someone but haven't yet?",
  "Who makes you feel most understood?",
  "What act of service could you do for someone you care about?",
  
  // Personal Growth & Learning
  "What did you discover about yourself today?",
  "What belief about yourself are you ready to change?",
  "What mistake taught you something valuable recently?",
  "How have you grown in the past month?",
  "What feedback have you received lately that was helpful?",
  "What pattern in your life would you like to change?",
  "What strength did you use today that you're proud of?",
  "What would your younger self think of who you are now?",
  "What life lesson are you still learning?",
  "How do you want to be remembered?",
  
  // Creativity & Imagination
  "What creative idea has been on your mind lately?",
  "If you could learn any art form, what would it be?",
  "What would you create if you had unlimited resources?",
  "What inspires your creativity most?",
  "What project would you start if you had more time?",
  "What would you write a book about?",
  "What song perfectly captures your mood right now?",
  "What color represents your current state of mind?",
  "If you could redesign your life like a work of art, what would it look like?",
  "What story from your life deserves to be told?",
  
  // Future Reflection
  "Where do you see yourself in five years?",
  "What legacy do you want to leave behind?",
  "What adventure do you dream of having?",
  "What change do you want to see in the world?",
  "How do you want to grow as a person this year?",
  "What tradition do you want to start?",
  "What place would you love to visit and why?",
  "What would your ideal day look like?",
  "What opportunity are you hoping will come your way?",
  "What do you want to be known for?",
  
  // Past Reflection
  "What childhood memory makes you smile?",
  "What decision are you most grateful for making?",
  "What has been your greatest accomplishment so far?",
  "What challenge from your past made you stronger?",
  "What advice would you give your past self?",
  "What moment in your life felt like a turning point?",
  "What tradition from your past do you want to continue?",
  "Who from your past would you like to reconnect with?",
  "What skill from your childhood do you miss using?",
  "What experience shaped who you are today?",
  
  // Values & Beliefs
  "What value is most important to you right now?",
  "What belief about life has served you well?",
  "What principle do you try to live by?",
  "What cause do you care deeply about?",
  "What does success mean to you personally?",
  "What does happiness look like in your life?",
  "What moral compass guides your decisions?",
  "What tradition or ritual is meaningful to you?",
  "What would you stand up for, even if you stood alone?",
  "What philosophy or quote resonates with you right now?",
  
  // Mindfulness & Awareness
  "What did you notice about your surroundings today that you usually miss?",
  "How present were you during your meals today?",
  "What sounds, smells, or textures stood out to you today?",
  "When did you feel most grounded today?",
  "What patterns in your thinking did you observe today?",
  "How did your breath feel during stressful moments?",
  "What moment today made you pause and appreciate the present?",
  "How did you practice mindfulness today?",
  "What physical sensations did you notice in your body today?",
  "When did you feel most connected to the moment?",
  
  // Work & Purpose
  "What aspect of your work brought you satisfaction today?",
  "How do you want to contribute to the world?",
  "What would you do if money wasn't a factor?",
  "What skills do you use that make you feel valuable?",
  "What project are you most passionate about?",
  "How do you want to make a difference?",
  "What would your dream job involve?",
  "What impact do you hope to have through your work?",
  "What motivates you to keep going when things get tough?",
  "How do you define meaningful work?",
  
  // Challenges & Problem-Solving
  "What obstacle are you currently facing, and what's one small step you could take?",
  "What problem would you love to solve?",
  "How do you typically handle stress?",
  "What difficult situation taught you something important?",
  "What fear have you overcome that you're proud of?",
  "What would you do if you weren't afraid?",
  "How do you bounce back from disappointment?",
  "What support do you need right now?",
  "What challenge are you avoiding that needs attention?",
  "What gives you strength during difficult times?",
  
  // Joy & Celebration
  "What made you laugh out loud recently?",
  "What small moment of beauty did you witness today?",
  "What are you celebrating in your life right now?",
  "What brings you pure, simple joy?",
  "What achievement, no matter how small, are you proud of?",
  "What makes you feel like dancing?",
  "What silly thing makes you happy?",
  "What surprise delighted you recently?",
  "What game or playful activity do you enjoy?",
  "What makes you feel like a kid again?",
  
  // Seasonal & Environmental
  "How did the weather affect your mood today?",
  "What season reflects your current state of mind?",
  "What place in nature makes you feel most at peace?",
  "How do you connect with the natural world around you?",
  "What changes in your environment would improve your well-being?",
  "What outdoor activity would you like to try?",
  "How does your physical space reflect who you are?",
  "What natural element (water, fire, earth, air) resonates with you today?",
  "What time of day do you feel most energized?",
  "How do the changing seasons mirror changes in your life?",
  
  // Health & Body
  "How did your body feel today?",
  "What movement brought you joy recently?",
  "How do you show appreciation for your body?",
  "What food nourished you well today?",
  "How do you listen to what your body needs?",
  "What physical activity makes you feel strong?",
  "How has your relationship with your body evolved?",
  "What does feeling healthy mean to you?",
  "How do you recharge when you're physically tired?",
  "What aspect of your physical health are you grateful for?",
  
  // Spirituality & Inner Life
  "What gives your life meaning?",
  "How do you connect with something larger than yourself?",
  "What brings you a sense of peace?",
  "What practices help you feel centered?",
  "What mystery about life fascinates you?",
  "How do you find hope during difficult times?",
  "What makes you feel most connected to others?",
  "What ritual or practice grounds you?",
  "What questions about existence interest you most?",
  "How do you cultivate inner wisdom?",
  
  // Learning & Discovery
  "What did you learn today that surprised you?",
  "What subject would you love to study more deeply?",
  "What skill are you currently developing?",
  "What book, podcast, or resource has influenced you recently?",
  "What question are you curious about right now?",
  "How do you prefer to learn new things?",
  "What knowledge do you wish you had?",
  "What expert would you love to have coffee with?",
  "What topic could you talk about for hours?",
  "What mistake taught you something valuable recently?",
  
  // Adventure & Exploration
  "What new experience would you like to try?",
  "What adventure is calling to you?",
  "What place would you love to explore?",
  "What activity outside your comfort zone interests you?",
  "What cultural experience would broaden your perspective?",
  "What path have you not taken that still intrigues you?",
  "What would you do if you had a free weekend with no plans?",
  "What type of adventure matches your personality?",
  "What discovery would excite you most?",
  "What boundary would you like to push in your life?",
  
  // Food & Nourishment
  "What meal brought you comfort recently?",
  "What food connects you to happy memories?",
  "How do you practice mindful eating?",
  "What dish would you love to learn to cook?",
  "What food tradition is meaningful to you?",
  "How does food bring people together in your life?",
  "What flavor perfectly captures your mood today?",
  "What relationship do you have with food?",
  "What meal would you prepare for someone you love?",
  "How do you nourish yourself beyond just food?",
  
  // Technology & Modern Life
  "How does technology enhance your life?",
  "What digital habit would you like to change?",
  "How do you maintain authentic connections in a digital world?",
  "What would you do with a day completely offline?",
  "How has technology changed your relationships?",
  "What online community or space brings you joy?",
  "How do you use technology to learn and grow?",
  "What balance do you seek between digital and analog experiences?",
  "How do you protect your mental health online?",
  "What technology are you grateful for?",
  
  // Money & Resources
  "What does financial well-being mean to you?",
  "How do you practice gratitude for what you have?",
  "What would you do with extra resources?",
  "How do you balance saving and enjoying life?",
  "What investment in yourself would pay the biggest dividends?",
  "How do you define wealth beyond money?",
  "What spending brings you genuine joy?",
  "How do you want to use your resources to help others?",
  "What financial goal are you working toward?",
  "What lesson about money has served you well?",
  
  // Time & Priorities
  "How did you spend your time today, and how do you feel about it?",
  "What deserves more of your time and attention?",
  "What activity makes you lose track of time?",
  "How do you want to spend your free time differently?",
  "What commitment are you ready to release?",
  "What does work-life balance look like for you?",
  "How do you prioritize when everything feels important?",
  "What would you do with an extra hour each day?",
  "How has your relationship with time evolved?",
  "What moment would you like to slow down and savor?",
  
  // Community & Service
  "How did you contribute to your community today?",
  "What cause would you like to support more actively?",
  "How do you want to be of service to others?",
  "What social issue concerns you most?",
  "How do you build bridges with people different from you?",
  "What volunteer work would be meaningful to you?",
  "How do you support the people in your life?",
  "What change would you like to see in your community?",
  "How do you practice compassion in daily life?",
  "What legacy of service would you like to leave?",
  
  // Family & Heritage
  "What family tradition do you cherish?",
  "What story from your family history inspires you?",
  "How do you honor your ancestors or heritage?",
  "What values did your family instill in you?",
  "What would you like to pass down to future generations?",
  "How has your family shaped who you are?",
  "What family recipe or tradition comforts you?",
  "What advice from a family member guides you?",
  "How do you stay connected with family?",
  "What family trait are you proud to have inherited?",
  
  // Communication & Expression
  "How did you express yourself authentically today?",
  "What conversation have you been wanting to have?",
  "How do you prefer to communicate with others?",
  "What message would you like to share with the world?",
  "How do you express love and appreciation?",
  "What story about yourself would you like others to know?",
  "How do you handle conflict in relationships?",
  "What words of encouragement do you need to hear?",
  "How do you practice active listening?",
  "What would you write in a letter to someone you love?",
  
  // Seasons of Life
  "What season of life are you in right now?",
  "What are you ready to let go of?",
  "What new chapter are you excited to begin?",
  "How have you changed in the past year?",
  "What transition are you currently navigating?",
  "What aspect of growing older excites you?",
  "What would you tell someone in a similar life stage?",
  "How do you embrace change in your life?",
  "What milestone are you approaching or celebrating?",
  "What wisdom have you gained through life experience?",
  
  // Dreams & Sleep
  "What did you dream about recently that stayed with you?",
  "What recurring dream or theme appears in your sleep?",
  "How do you prepare your mind for restful sleep?",
  "What hopes and dreams visit you in quiet moments?",
  "What would you like to dream about tonight?",
  "How does your sleep affect your daily life?",
  "What bedtime ritual helps you wind down?",
  "What keeps you awake at night, and how can you address it?",
  "What dream from childhood do you still remember?",
  "How do you interpret the messages from your dreams?",
  
  // Art & Beauty
  "What beautiful thing did you notice today?",
  "What art form speaks to your soul?",
  "How do you surround yourself with beauty?",
  "What creative work has moved you recently?",
  "How do you express your aesthetic preferences?",
  "What makes something beautiful to you?",
  "What would you create if you were an artist?",
  "How does beauty affect your mood and well-being?",
  "What cultural art form would you like to explore?",
  "How do you appreciate the art in everyday life?",
  
  // Music & Sound
  "What song perfectly captures your current mood?",
  "What music brings back powerful memories?",
  "How does music affect your emotions?",
  "What would be on the soundtrack of your life?",
  "What instrument would you love to learn to play?",
  "What sounds in nature bring you peace?",
  "How do you use music to change your state of mind?",
  "What concert or musical experience was transformative for you?",
  "What song makes you want to dance?",
  "How does silence serve you in your daily life?",
  
  // Play & Recreation
  "What activity makes you feel playful and free?",
  "How do you incorporate fun into your daily routine?",
  "What game or sport brings you joy?",
  "How do you reconnect with your sense of wonder?",
  "What hobby would you pursue if you had more time?",
  "What makes you laugh until your sides hurt?",
  "How do you celebrate small wins in life?",
  "What playful activity from childhood do you miss?",
  "How do you balance seriousness with lightheartedness?",
  "What adventure would make your inner child excited?",
  
  // Random & Unique Prompts
  "If you could have dinner with anyone, living or dead, who would it be and why?",
  "What superpower would best serve your life purpose?",
  "What would you do if you inherited a million dollars tomorrow?",
  "What animal best represents your personality and why?",
  "If you could master any skill instantly, what would it be?",
  "What question would you ask a wise oracle?",
  "What would you put in a time capsule for future generations?",
  "If you could live in any time period, when would it be?",
  "What three words would you want others to use to describe you?",
  "What would you do if you knew you couldn't fail?",
  "What advice would you give to someone starting their adult life?",
  "What would you change about the world if you had the power?",
  "What's the most important lesson life has taught you so far?",
  "What would you do with a completely free day?",
  "What makes you feel most confident and powerful?",
  "What story about yourself do you love to tell?",
  "What would your perfect home look like and feel like?",
  "What activity makes you lose all sense of time?",
  "What quality do you most admire in others?",
  "What adventure would push you outside your comfort zone in the best way?",
  
  // Evening Reflection
  "What are you proud of accomplishing today?",
  "How did you show up for yourself today?",
  "What deserves your attention tomorrow?",
  "What are you releasing from today?",
  "How do you want to feel when you wake up tomorrow?",
  "What intention do you want to set for tomorrow?",
  "What went better than expected today?",
  "How did you honor your values today?",
  "What support do you need to ask for?",
  "What are you looking forward to in the coming days?",
  
  // Morning Intention
  "What energy do you want to bring to today?",
  "What are you most excited about today?",
  "How do you want to take care of yourself today?",
  "What intention will guide your actions today?",
  "What opportunity might present itself today?",
  "How do you want to connect with others today?",
  "What challenge are you ready to face today?",
  "What gratitude will you carry with you today?",
  "What small act of kindness can you do today?",
  "How will you make today meaningful?",
  
  // Philosophical & Deep Thinking
  "What does it mean to live a good life?",
  "How do you define success versus fulfillment?",
  "What role does suffering play in personal growth?",
  "What do you believe happens after we die?",
  "How do you find meaning in difficult experiences?",
  "What is your relationship with uncertainty?",
  "How do you balance individual needs with collective responsibility?",
  "What does forgiveness mean to you?",
  "How do you navigate moral dilemmas?",
  "What is your understanding of love?",
  
  // Final Unique Prompts
  "What would you regret not doing if your life ended today?",
  "What mask are you ready to take off?",
  "What would self-compassion look like in your life right now?",
  "What pattern in your life are you ready to break?",
  "What would radical self-acceptance change about your daily experience?",
  "What truth about yourself are you still learning to accept?",
  "What gift do you have that the world needs?",
  "What would living authentically look like for you?",
  "What story about yourself is ready to be rewritten?",
  "What would you do if you truly believed you were enough, just as you are?"
];

interface JournalPromptProps {
  moodValue: number;
  dayRating: number;
  savedEntry?: string;
  onBack: () => void;
  onComplete: (journalEntry: string) => void;
  onSkipToAnalytics: () => void;
  onViewAnalytics: () => void;
  onViewMemories: () => void;
  onViewFavorites: () => void;
  onViewFAQ?: () => void;
}

export function JournalPrompt({ moodValue, dayRating, savedEntry = '', onBack, onComplete, onSkipToAnalytics, onViewAnalytics, onViewMemories, onViewFavorites, onViewFAQ }: JournalPromptProps) {
  const [journalEntry, setJournalEntry] = useState(savedEntry);
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [currentPrompt] = useState(() => {
    // Select a random prompt
    return journalPrompts[Math.floor(Math.random() * journalPrompts.length)];
  });

  const moodLabel = moodLabels[moodValue as keyof typeof moodLabels];
  const dayLabel = dayLabels[dayRating as keyof typeof dayLabels];

  const handleSave = () => {
    onComplete(journalEntry);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center p-4">
      <div className="w-full max-w-lg mx-auto">
        <div className="bg-card rounded-2xl shadow-lg border p-8 space-y-6 relative">
          {/* Navigation Menu */}
          <NavigationMenu
            sidebarOpen={sidebarOpen}
            setSidebarOpen={setSidebarOpen}
            onViewAnalytics={onViewAnalytics}
            onViewMemories={onViewMemories}
            onViewFavorites={onViewFavorites}
            onViewFAQ={onViewFAQ}
            currentPage="journal"
          />
          
          {/* Header */}
          <div className="mb-6">
            {/* Back button */}
            <div className="flex justify-start mb-4">
              <button
                onClick={onBack}
                className="p-2 rounded-lg bg-secondary hover:bg-secondary/80 transition-colors"
              >
                <ArrowLeft className="h-5 w-5" />
              </button>
            </div>
            
            {/* Centered titles */}
            <div className="text-center space-y-2">
              <h1 className="text-2xl">Journal Reflection</h1>
              <p className="text-sm text-muted-foreground">
                Take a moment to reflect on your day
              </p>
            </div>
          </div>

          {/* Summary of selections */}
          <div className="bg-secondary/50 rounded-lg p-4 space-y-2">
            <div className="text-center space-y-1">
              <p className="text-sm text-muted-foreground">Today's Check-in</p>
              <div className="flex justify-center items-center gap-4">
                <span className="text-sm">
                  <strong>Mood:</strong> {moodLabel} ({moodValue}/10)
                </span>
                <span className="text-muted-foreground">•</span>
                <span className="text-sm">
                  <strong>Day:</strong> {dayLabel} ({dayRating}/5)
                </span>
              </div>
            </div>
          </div>

          {/* Journal prompt */}
          <div className="space-y-4">
            <div className="text-center">
              <div className="flex items-center justify-center gap-2 mb-4">
                <h3 className="text-lg text-muted-foreground">
                  {currentPrompt}
                </h3>
                <FeatureExplainer 
                  title="Journal Prompts"
                  description="Each day you'll receive a thoughtful prompt from our collection of over 1,000 questions. Journaling helps process emotions, gain self-awareness, and track personal growth."
                />
              </div>
            </div>

            {/* Text area */}
            <div className="space-y-2">
              <Textarea
                placeholder="Write your thoughts here..."
                value={journalEntry}
                onChange={(e) => setJournalEntry(e.target.value)}
                className="min-h-[200px] resize-none"
              />
              <p className="text-xs text-muted-foreground text-right">
                {journalEntry.length} characters
              </p>
            </div>
          </div>

          {/* Action buttons */}
          <div className="space-y-3 pt-4">
            <button 
              className="w-full bg-primary text-primary-foreground py-3 px-6 rounded-lg hover:opacity-90 transition-opacity disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:opacity-50"
              onClick={handleSave}
              disabled={journalEntry.trim().length === 0}
            >
              Save Entry
            </button>
            
            {/* Skip to Analytics button */}
            <button 
              className="w-full bg-secondary/50 text-secondary-foreground py-2.5 px-6 rounded-lg hover:bg-secondary/70 transition-colors text-sm"
              onClick={onSkipToAnalytics}
            >
              Skip Activity & Go to Analytics →
            </button>
          </div>

          {/* Footer message */}
          <div className="text-center pt-4 border-t">
            <p className="text-sm text-muted-foreground">
              Your thoughts and feelings are valid.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}