import React, { useState, useEffect } from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Calendar } from './ui/calendar';
import { NavigationMenu } from './NavigationMenu';
import { WordCloud } from './WordCloud';
import { FeatureExplainer } from './FeatureExplainer';

interface MoodEntry {
  date: string;
  mood: number;
  dayRating: number;
  journalPrompt: string;
  journalAnswer: string;
  activityTitle?: string;
  activityPhoto?: string;
}

interface AnalyticsProps {
  onBackToHome: () => void;
  onViewMemories: () => void;
  onViewFavorites: () => void;
  onViewFAQ?: () => void;
}

// Helper function to get mood emoji
const getMoodEmoji = (mood: number): string => {
  if (mood <= 2) return '😢';
  if (mood <= 4) return '😔';
  if (mood <= 6) return '😐';
  if (mood <= 8) return '😊';
  return '🤩';
};

// Helper function to get mood description
const getMoodDescription = (mood: number): string => {
  if (mood <= 2) return 'Very Low';
  if (mood <= 4) return 'Low';
  if (mood <= 6) return 'Neutral';
  if (mood <= 8) return 'Good';
  return 'Excellent';
};

// Mock data for calendar - matches Memories page data
const mockMoodEntries = {
  '2025-10-01': { mood: 8, dayRating: 4, emoji: '😊', activity: 'Morning Coffee', photo: 'https://images.unsplash.com/photo-1518057111178-44a106bad636?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=400&h=400&fit=crop' },
  '2025-10-02': { mood: 6, dayRating: 3, emoji: '😐' },
  '2025-10-03': { mood: 9, dayRating: 5, emoji: '😄', activity: 'Yoga Session', photo: 'https://images.unsplash.com/photo-1506126613408-eca07ce68773?w=400&h=400&fit=crop' },
  '2025-10-05': { mood: 4, dayRating: 2, emoji: '😢' },
  '2025-10-07': { mood: 7, dayRating: 4, emoji: '🙂', activity: 'Sunset Walk', photo: 'https://images.unsplash.com/photo-1470252649378-9c29740c9fa8?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=400&h=400&fit=crop' },
  '2025-10-08': { mood: 8, dayRating: 4, emoji: '😊', activity: 'Hiking Adventure', photo: 'https://images.unsplash.com/photo-1592859600972-1b0834d83747?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=400&h=400&fit=crop' },
  '2025-10-10': { mood: 10, dayRating: 5, emoji: '🤩', activity: 'Time with Friends', photo: 'https://images.unsplash.com/photo-1625283518288-00362afc8663?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=400&h=400&fit=crop' },
  '2025-10-12': { mood: 5, dayRating: 3, emoji: '😕' },
  '2025-10-13': { mood: 8, dayRating: 4, emoji: '😊', activity: 'Meditation', photo: 'https://images.unsplash.com/photo-1716816211509-6e7b2c82d845?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=400&h=400&fit=crop' },
  '2025-10-15': { mood: 8, dayRating: 4, emoji: '😊', activity: 'City Exploration', photo: 'https://images.unsplash.com/photo-1493134799591-2c9eed26201a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=400&h=400&fit=crop' },
  '2025-10-16': { mood: 7, dayRating: 4, emoji: '🙂' },
  '2025-10-17': { mood: 9, dayRating: 5, emoji: '😄', activity: 'Garden Time', photo: 'https://images.unsplash.com/photo-1625720375970-137907e1de41?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=400&h=400&fit=crop' },
  '2025-10-18': { mood: 9, dayRating: 5, emoji: '😄', activity: 'Healthy Cooking', photo: 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=400&h=400&fit=crop' },
  '2025-10-20': { mood: 7, dayRating: 4, emoji: '🙂' },
};

// Generate mock historical data with realistic mood trends
const generateMockData = (): MoodEntry[] => {
  const data: MoodEntry[] = [];
  const prompts = [
    "What made you smile today?",
    "Describe a moment when you felt proud of yourself.",
    "What's one thing you're grateful for right now?",
    "How did you take care of yourself today?",
    "What challenged you today and how did you handle it?"
  ];
  
  const activities = [
    "Take a Gentle Walk",
    "Practice Deep Breathing", 
    "Try Creative Expression",
    "Call a Friend",
    "Go for a Nature Walk"
  ];

  const journalAnswers = [
    "Today was peaceful and calm. I spent time with my family and felt really connected to them. The simple moments of laughter and conversation brought me so much joy and happiness.",
    "I felt anxious this morning but taking a walk in nature helped me feel grounded and centered. The fresh air and sunshine made such a difference in my mood and energy.",
    "Work was challenging today but I'm proud of how I handled the stress. I took breaks when needed and practiced deep breathing to stay calm and focused.",
    "I'm grateful for my friends who always support me. Their kindness and encouragement means the world to me and helps me through difficult times.",
    "Today I felt creative and inspired. I spent time painting and lost myself in the process. Art brings me peace and helps me express my emotions.",
    "I struggled with motivation today but I was gentle with myself. Sometimes rest and self-compassion are more important than productivity.",
    "Meditation this morning helped me start the day with clarity and intention. I felt more mindful and present throughout the entire day.",
    "I'm learning to set better boundaries in my relationships. It's hard but necessary for my mental health and wellbeing.",
    "Exercise today made me feel strong and capable. Moving my body always improves my mood and helps me feel more energized and alive.",
    "I practiced gratitude today and noticed the small beautiful things around me. The sunset was breathtaking and filled me with wonder and appreciation.",
    "Today I felt overwhelmed with responsibilities but I tackled them one step at a time. Progress not perfection is my new mantra.",
    "Spending time in my garden brought me peace and joy. Watching things grow reminds me of my own personal growth and transformation.",
    "I had a meaningful conversation with a friend that left me feeling understood and supported. Connection is so important for my emotional wellbeing.",
    "Today I felt confident in my abilities. I accomplished tasks that seemed difficult before and surprised myself with my strength and resilience.",
    "I took time for self-care today with a relaxing bath and good book. These quiet moments of solitude help me recharge and restore my energy.",
    "Music lifted my spirits today. Dancing around the house made me feel free and joyful like a child again.",
    "I'm learning to accept my emotions without judgment. Sadness and difficult feelings are part of life and that's okay.",
    "Today brought unexpected joy when I received kindness from a stranger. Small acts of compassion make the world feel warmer and more hopeful.",
    "I felt productive and accomplished today. Checking items off my list gave me a sense of progress and achievement.",
    "Cooking a healthy meal for myself felt like an act of love. Nourishing my body helps me feel strong and cared for."
  ];

  // Create a more realistic mood trend with ups and downs
  let baseMood = 6; // Start with neutral-positive mood
  
  for (let i = 30; i >= 0; i--) {
    const date = new Date();
    date.setDate(date.getDate() - i);
    
    // Create more gradual mood changes for realistic trends
    const moodChange = (Math.random() - 0.5) * 2; // Random change between -1 and +1
    baseMood = Math.max(1, Math.min(10, baseMood + moodChange)); // Keep within 1-10 range
    
    const mood = Math.round(baseMood);
    const dayRating = Math.max(1, Math.min(5, Math.round(mood / 2))); // Day rating correlates with mood
    
    data.push({
      date: date.toISOString().split('T')[0],
      mood: mood,
      dayRating: dayRating,
      journalPrompt: prompts[Math.floor(Math.random() * prompts.length)],
      journalAnswer: journalAnswers[Math.floor(Math.random() * journalAnswers.length)],
      activityTitle: Math.random() > 0.3 ? activities[Math.floor(Math.random() * activities.length)] : undefined,
      activityPhoto: Math.random() > 0.7 ? "https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?w=400" : undefined
    });
  }
  
  return data;
};

export function Analytics({ onBackToHome, onViewMemories, onViewFavorites, onViewFAQ }: AnalyticsProps) {
  const [entries, setEntries] = useState<MoodEntry[]>([]);
  const [timeRange, setTimeRange] = useState<'week' | 'month' | 'year'>('month');
  const [sidebarOpen, setSidebarOpen] = useState(false);

  useEffect(() => {
    // In a real app, this would fetch from a database
    const mockData = generateMockData();
    setEntries(mockData);
  }, []);

  // Filter data based on time range
  const getFilteredData = () => {
    const now = new Date();
    const cutoffDate = new Date();
    
    switch (timeRange) {
      case 'week':
        cutoffDate.setDate(now.getDate() - 7);
        break;
      case 'month':
        cutoffDate.setMonth(now.getMonth() - 1);
        break;
      case 'year':
        cutoffDate.setFullYear(now.getFullYear() - 1);
        break;
    }
    
    return entries
      .filter(entry => new Date(entry.date) >= cutoffDate)
      .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
  };

  const chartData = getFilteredData().map(entry => ({
    date: new Date(entry.date).toLocaleDateString('en-US', { 
      month: 'short', 
      day: 'numeric' 
    }),
    mood: entry.mood,
    dayRating: entry.dayRating
  }));

  // Calculate averages
  const filteredEntries = getFilteredData();
  const avgMood = filteredEntries.length > 0 
    ? (filteredEntries.reduce((sum, entry) => sum + entry.mood, 0) / filteredEntries.length).toFixed(1)
    : '0';
  const avgDayRating = filteredEntries.length > 0
    ? (filteredEntries.reduce((sum, entry) => sum + entry.dayRating, 0) / filteredEntries.length).toFixed(1)
    : '0';

  // Calculate mood streaks
  const calculateStreak = () => {
    let currentStreak = 0;
    const sortedEntries = [...entries].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
    
    for (let i = 0; i < sortedEntries.length; i++) {
      const entryDate = new Date(sortedEntries[i].date);
      const today = new Date();
      const diffDays = Math.floor((today.getTime() - entryDate.getTime()) / (1000 * 60 * 60 * 24));
      
      if (diffDays === i) {
        currentStreak++;
      } else {
        break;
      }
    }
    return currentStreak;
  };

  // Find best and worst days
  const bestDay = filteredEntries.length > 0 
    ? filteredEntries.reduce((best, entry) => entry.mood > best.mood ? entry : best)
    : null;
  
  const worstDay = filteredEntries.length > 0
    ? filteredEntries.reduce((worst, entry) => entry.mood < worst.mood ? entry : worst)
    : null;

  // Calculate activity completion rate
  const completedActivities = filteredEntries.filter(entry => entry.activityTitle).length;
  const activityRate = filteredEntries.length > 0 
    ? Math.round((completedActivities / filteredEntries.length) * 100)
    : 0;

  // Get most common activities
  const activityCounts = filteredEntries.reduce((acc, entry) => {
    if (entry.activityTitle) {
      acc[entry.activityTitle] = (acc[entry.activityTitle] || 0) + 1;
    }
    return acc;
  }, {} as Record<string, number>);

  const topActivities = Object.entries(activityCounts)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 3);

  const currentStreak = calculateStreak();

  // Calendar helper functions - using same data as Memories page
  const formatDateKey = (date: Date) => {
    return date.toISOString().split('T')[0];
  };

  const hasEntryForDate = (date: Date) => {
    const dateKey = formatDateKey(date);
    return dateKey in mockMoodEntries;
  };

  const hasPhotoForDate = (date: Date) => {
    const dateKey = formatDateKey(date);
    const entry = mockMoodEntries[dateKey as keyof typeof mockMoodEntries];
    return entry && entry.photo;
  };

  const getPhotoForDate = (date: Date) => {
    const dateKey = formatDateKey(date);
    const entry = mockMoodEntries[dateKey as keyof typeof mockMoodEntries];
    return entry?.photo;
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-4 pb-8">
      <div className="max-w-md mx-auto space-y-4 relative">
        {/* Navigation Menu */}
        <div className="relative">
          <NavigationMenu
            sidebarOpen={sidebarOpen}
            setSidebarOpen={setSidebarOpen}
            onViewAnalytics={() => {}} // Already on analytics
            onViewMemories={onViewMemories}
            onViewFavorites={onViewFavorites}
            onViewFAQ={onViewFAQ}
            currentPage="analytics"
          />
        </div>
        
        {/* Header */}
        <div className="text-center space-y-2">
          <button 
            onClick={onBackToHome}
            className="w-full bg-secondary text-secondary-foreground py-3 px-4 rounded-lg hover:opacity-90 transition-opacity mb-4"
          >
            ← Back to Home
          </button>
          <h1 className="text-2xl" style={{ fontFamily: 'cursive' }}>MindScape Analytics</h1>
          <p className="text-sm text-muted-foreground">Track your emotional journey</p>
        </div>

        {/* Stats Cards */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-center">Your Stats</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-3 gap-4 text-center">
              <div>
                <div className="text-lg flex items-center justify-center gap-1">
                  {getMoodEmoji(Number(avgMood))} {avgMood}
                </div>
                <p className="text-xs text-muted-foreground">Avg Mood</p>
              </div>
              <div>
                <div className="text-lg">⭐ {avgDayRating}</div>
                <p className="text-xs text-muted-foreground">Avg Day</p>
              </div>
              <div>
                <div className="text-lg">📝 {filteredEntries.length}</div>
                <p className="text-xs text-muted-foreground">Entries</p>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4 text-center pt-2 border-t">
              <div>
                <div className="text-lg">🔥 {currentStreak}</div>
                <p className="text-xs text-muted-foreground">Day Streak</p>
              </div>
              <div>
                <div className="text-lg">✅ {activityRate}%</div>
                <p className="text-xs text-muted-foreground">Activity Rate</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Time Range Selector */}
        <Card>
          <CardContent className="p-4">
            <Tabs value={timeRange} onValueChange={(value) => setTimeRange(value as 'week' | 'month' | 'year')} className="w-full">
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="week" className="text-sm">Week</TabsTrigger>
                <TabsTrigger value="month" className="text-sm">Month</TabsTrigger>
                <TabsTrigger value="year" className="text-sm">Year</TabsTrigger>
              </TabsList>
            </Tabs>
          </CardContent>
        </Card>

        {/* Chart Section */}
        <Card>
          <CardHeader className="pb-3">
            <div className="flex items-center justify-center gap-2">
              <CardTitle className="text-center">Mood Trends</CardTitle>
              <FeatureExplainer 
                title="Mood Trends Chart"
                description="This chart visualizes your mood patterns over time. Look for trends, cycles, and improvements. Understanding your patterns can help you identify what positively or negatively impacts your well-being."
              />
            </div>
            <CardDescription className="text-center text-sm">Your emotional patterns over time</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={280}>
              <LineChart data={chartData} margin={{ top: 5, right: 10, left: -10, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" opacity={0.3} />
                <XAxis 
                  dataKey="date" 
                  tick={{ fontSize: 11 }}
                  interval="preserveStartEnd"
                  stroke="hsl(var(--muted-foreground))"
                />
                <YAxis 
                  domain={[0, 10]} 
                  tick={{ fontSize: 11 }}
                  stroke="hsl(var(--muted-foreground))"
                  label={{ value: 'Mood Level', angle: -90, position: 'insideLeft', style: { fontSize: 11 } }}
                />
                <Tooltip 
                  contentStyle={{ 
                    fontSize: '13px',
                    backgroundColor: 'hsl(var(--card))',
                    border: '1px solid hsl(var(--border))',
                    borderRadius: '8px',
                    padding: '8px 12px'
                  }}
                  labelStyle={{ fontWeight: 600, marginBottom: '4px' }}
                />
                <Line 
                  type="monotone" 
                  dataKey="mood" 
                  stroke="hsl(var(--primary))" 
                  strokeWidth={3}
                  name="Mood"
                  dot={{ r: 5, fill: 'hsl(var(--primary))', strokeWidth: 2, stroke: '#fff' }}
                  activeDot={{ r: 7 }}
                />
                <Line 
                  type="monotone" 
                  dataKey="dayRating" 
                  stroke="#8b5cf6" 
                  strokeWidth={2}
                  name="Day Rating"
                  dot={{ r: 3, fill: '#8b5cf6' }}
                  strokeDasharray="5 5"
                  opacity={0.6}
                />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Word Cloud Section */}
        <Card>
          <CardHeader className="pb-3">
            <div className="flex items-center justify-center gap-2">
              <CardTitle className="text-center">Word Cloud</CardTitle>
              <FeatureExplainer 
                title="Word Cloud"
                description="This visual representation shows the most frequently used words in your recent journal entries. Larger words appear more often. It helps you see recurring themes and topics in your reflections."
              />
            </div>
            <CardDescription className="text-center text-sm">
              Key words from your 10 most recent journal entries
            </CardDescription>
          </CardHeader>
          <CardContent>
            <WordCloud 
              journalEntries={filteredEntries.map(entry => entry.journalAnswer)}
            />
          </CardContent>
        </Card>

        {/* Insights Card */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-center">Insights</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {/* Best and Worst Days */}
            <div className="grid grid-cols-2 gap-4">
              {bestDay && (
                <div className="p-3 bg-green-50 dark:bg-green-950 rounded-lg">
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-lg">🌟</span>
                    <p className="text-xs">Best Day</p>
                  </div>
                  <p className="text-sm">
                    {new Date(bestDay.date).toLocaleDateString('en-US', { 
                      month: 'short', 
                      day: 'numeric' 
                    })}
                  </p>
                  <p className="text-xs text-muted-foreground">Mood: {bestDay.mood}/10</p>
                </div>
              )}
              {worstDay && (
                <div className="p-3 bg-blue-50 dark:bg-blue-950 rounded-lg">
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-lg">💙</span>
                    <p className="text-xs">Growth Day</p>
                  </div>
                  <p className="text-sm">
                    {new Date(worstDay.date).toLocaleDateString('en-US', { 
                      month: 'short', 
                      day: 'numeric' 
                    })}
                  </p>
                  <p className="text-xs text-muted-foreground">Mood: {worstDay.mood}/10</p>
                </div>
              )}
            </div>

            {/* Top Activities */}
            {topActivities.length > 0 && (
              <div className="pt-2 border-t">
                <p className="text-sm mb-2">Top Activities</p>
                <div className="space-y-2">
                  {topActivities.map(([activity, count], index) => (
                    <div key={index} className="flex items-center justify-between text-sm">
                      <span className="text-xs">{activity}</span>
                      <Badge variant="secondary" className="text-xs">{count}x</Badge>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Calendar View Section */}
        <Card>
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <CardTitle>Calendar View</CardTitle>
                <FeatureExplainer 
                  title="Interactive Calendar"
                  description="Days with mood entries are highlighted in blue. Days with photos show a preview. Click 'Full View' to see all your memories and journal entries in an interactive calendar format."
                />
              </div>
              <button
                onClick={onViewMemories}
                className="text-xs text-primary hover:underline"
              >
                Full View →
              </button>
            </div>
          </CardHeader>
          <CardContent>
            {/* Calendar */}
            <div className="flex justify-center">
              <Calendar
                mode="single"
                className="rounded-md border photo-calendar pointer-events-none"
                modifiers={{
                  hasEntry: (date) => hasEntryForDate(date) && !hasPhotoForDate(date),
                  hasPhoto: (date) => hasPhotoForDate(date)
                }}
                modifiersStyles={{
                  hasEntry: {
                    backgroundColor: 'hsl(var(--primary))',
                    color: 'hsl(var(--primary-foreground))',
                    borderRadius: '50%'
                  },
                  hasPhoto: {
                    borderRadius: '50%',
                    overflow: 'hidden',
                    border: '2px solid hsl(var(--primary))',
                    background: 'transparent',
                    position: 'relative'
                  }
                }}
                components={{
                  DayContent: ({ date }) => {
                    const photo = getPhotoForDate(date);
                    const hasEntry = hasEntryForDate(date);
                    
                    if (photo) {
                      return (
                        <div className="relative w-full h-full flex items-center justify-center">
                          <div 
                            className="absolute inset-0 rounded-full"
                            style={{
                              backgroundImage: `url(${photo})`,
                              backgroundSize: 'cover',
                              backgroundPosition: 'center',
                              opacity: 0.85
                            }}
                          />
                          <div className="absolute inset-0 bg-gradient-to-b from-transparent via-transparent to-black/40 rounded-full" />
                          <span className="relative text-white font-semibold drop-shadow-[0_2px_4px_rgba(0,0,0,0.8)] z-10">
                            {date.getDate()}
                          </span>
                        </div>
                      );
                    }
                    
                    // Show date with dot indicator for entries without photos
                    if (hasEntry) {
                      return (
                        <div className="relative w-full h-full flex items-center justify-center">
                          <span>{date.getDate()}</span>
                          <div className="absolute bottom-0 left-1/2 -translate-x-1/2 translate-y-1 w-1 h-1 bg-primary rounded-full" />
                        </div>
                      );
                    }
                    
                    return <span>{date.getDate()}</span>;
                  }
                }}
              />
            </div>
          </CardContent>
        </Card>

        {/* Recent Memories Section */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle>Recent Memories</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {entries.slice(0, 3).reverse().map((entry, index) => (
                <div key={index} className="p-4 bg-secondary/50 rounded-lg hover:bg-secondary/70 transition-colors">
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <span className="text-lg">{getMoodEmoji(entry.mood)}</span>
                      <span className="text-sm">
                        {new Date(entry.date).toLocaleDateString('en-US', { 
                          month: 'short', 
                          day: 'numeric',
                          year: 'numeric'
                        })}
                      </span>
                    </div>
                    <div className="text-xs text-muted-foreground">
                      {entry.mood}/10
                    </div>
                  </div>
                  <p className="text-xs text-muted-foreground mb-2 line-clamp-2">
                    {entry.journalPrompt}
                  </p>
                  <div className="flex items-center gap-2">
                    {entry.activityTitle && (
                      <Badge variant="outline" className="text-xs">{entry.activityTitle}</Badge>
                    )}
                    {entry.activityPhoto && (
                      <span className="text-xs">📸</span>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}