import React, { useState } from 'react';
import { Calendar } from './ui/calendar';
import { ArrowLeft } from 'lucide-react';
import { NavigationMenu } from './NavigationMenu';

interface MemoriesProps {
  onBackToHome: () => void;
  onViewAnalytics: () => void;
  onViewFavorites: () => void;
  onViewFAQ?: () => void;
}

// Mock data for demonstration - in a real app this would come from your database
const mockMoodEntries = {
  '2025-10-01': { mood: 8, dayRating: 4, emoji: '😊', activity: 'Morning Coffee', photo: 'https://images.unsplash.com/photo-1518057111178-44a106bad636?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=400&h=400&fit=crop', prompt: 'What simple pleasure brought you joy today?', journal: 'Started the day with a wonderful cup of coffee and some quiet time. Feeling grateful for these peaceful moments.' },
  '2025-10-02': { mood: 6, dayRating: 3, emoji: '😐', prompt: 'What would you do differently if you could relive today?', journal: 'Just an average day. Nothing particularly exciting happened, but I\'m trying to find joy in the small moments.' },
  '2025-10-03': { mood: 9, dayRating: 5, emoji: '😄', activity: 'Yoga Session', photo: 'https://images.unsplash.com/photo-1506126613408-eca07ce68773?w=400&h=400&fit=crop', prompt: 'How did you take care of yourself today?', journal: 'Amazing yoga session this morning! Felt so centered and connected to my body. This is exactly what I needed.' },
  '2025-10-05': { mood: 4, dayRating: 2, emoji: '😢', prompt: 'What challenged you today and how did you handle it?', journal: 'Tough day today. Feeling a bit overwhelmed with everything on my plate. Reminding myself that it\'s okay to have difficult days.' },
  '2025-10-07': { mood: 7, dayRating: 4, emoji: '🙂', activity: 'Sunset Walk', photo: 'https://images.unsplash.com/photo-1470252649378-9c29740c9fa8?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=400&h=400&fit=crop', prompt: 'What place in nature makes you feel most at peace?', journal: 'The sunset walk was exactly what I needed. Nature has a way of putting things into perspective.' },
  '2025-10-08': { mood: 8, dayRating: 4, emoji: '😊', activity: 'Hiking Adventure', photo: 'https://images.unsplash.com/photo-1592859600972-1b0834d83747?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=400&h=400&fit=crop', prompt: 'What made you feel proud of yourself recently?', journal: 'What an incredible hike! Pushed myself to reach the summit and the view was absolutely worth it.' },
  '2025-10-10': { mood: 10, dayRating: 5, emoji: '🤩', activity: 'Time with Friends', photo: 'https://images.unsplash.com/photo-1625283518288-00362afc8663?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=400&h=400&fit=crop', prompt: 'What relationship in your life brings you the most joy?', journal: 'Best day ever! Spent quality time with my closest friends. These are the moments that matter most.' },
  '2025-10-12': { mood: 5, dayRating: 3, emoji: '😕', prompt: 'What thoughts or feelings are on your mind?', journal: 'Feeling a bit uncertain about the future today. Taking time to reflect on what really matters to me.' },
  '2025-10-13': { mood: 8, dayRating: 4, emoji: '😊', activity: 'Meditation', photo: 'https://images.unsplash.com/photo-1716816211509-6e7b2c82d845?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=400&h=400&fit=crop', prompt: 'What practices help you feel centered?', journal: 'My morning meditation practice is really helping me stay grounded and focused throughout the day.' },
  '2025-10-15': { mood: 8, dayRating: 4, emoji: '😊', activity: 'City Exploration', photo: 'https://images.unsplash.com/photo-1493134799591-2c9eed26201a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=400&h=400&fit=crop', prompt: 'What beautiful thing did you notice today?', journal: 'Explored a new part of the city today. It\'s amazing how much beauty there is when you take the time to look.' },
  '2025-10-16': { mood: 7, dayRating: 4, emoji: '🙂', prompt: 'What are you proud of accomplishing today?', journal: 'Productive day at work. Feeling accomplished and ready to tackle tomorrow\'s challenges.' },
  '2025-10-17': { mood: 9, dayRating: 5, emoji: '😄', activity: 'Garden Time', photo: 'https://images.unsplash.com/photo-1625720375970-137907e1de41?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=400&h=400&fit=crop', prompt: 'What activity makes you lose track of time?', journal: 'Spent the afternoon in the garden. There\'s something therapeutic about getting my hands dirty and watching things grow.' },
  '2025-10-18': { mood: 9, dayRating: 5, emoji: '😄', activity: 'Healthy Cooking', photo: 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=400&h=400&fit=crop', prompt: 'How do you nourish yourself beyond just food?', journal: 'Cooked a delicious and healthy meal today. Taking care of my body feels like an act of self-love.' },
  '2025-10-20': { mood: 7, dayRating: 4, emoji: '🙂', prompt: 'What moment would you like to slow down and savor?', journal: 'A quiet, peaceful day. Sometimes the simple days are the best ones.' },
};

export function Memories({ onBackToHome, onViewAnalytics, onViewFavorites, onViewFAQ }: MemoriesProps) {
  const [selectedDate, setSelectedDate] = useState<Date | undefined>();
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const formatDateKey = (date: Date) => {
    return date.toISOString().split('T')[0];
  };

  const getSelectedDateEntry = () => {
    if (!selectedDate) return null;
    const dateKey = formatDateKey(selectedDate);
    return mockMoodEntries[dateKey as keyof typeof mockMoodEntries] || null;
  };

  const hasEntryForDate = (date: Date) => {
    const dateKey = formatDateKey(date);
    return dateKey in mockMoodEntries;
  };

  const hasPhotoForDate = (date: Date) => {
    const dateKey = formatDateKey(date);
    const entry = mockMoodEntries[dateKey as keyof typeof mockMoodEntries];
    return entry && entry.photo;
  };

  const getPhotoForDate = (date: Date) => {
    const dateKey = formatDateKey(date);
    const entry = mockMoodEntries[dateKey as keyof typeof mockMoodEntries];
    return entry?.photo;
  };

  const selectedEntry = getSelectedDateEntry();

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center p-4">
      <div className="w-full max-w-lg mx-auto">
        <div className="bg-card rounded-2xl shadow-lg border p-8 relative">
          {/* Navigation Menu */}
          <NavigationMenu
            sidebarOpen={sidebarOpen}
            setSidebarOpen={setSidebarOpen}
            onViewAnalytics={onViewAnalytics}
            onViewMemories={() => {}} // Already on memories
            onViewFavorites={onViewFavorites}
            onViewFAQ={onViewFAQ}
            currentPage="memories"
          />
          
          {/* Header */}
          <div className="mb-6">
            {/* Back button */}
            <div className="flex justify-start mb-4">
              <button
                onClick={onBackToHome}
                className="p-2 rounded-lg bg-secondary hover:bg-secondary/80 transition-colors"
              >
                <ArrowLeft className="h-5 w-5" />
              </button>
            </div>
            
            {/* Centered titles */}
            <div className="text-center">
              <h1 className="text-3xl text-primary mb-2" style={{ fontFamily: 'cursive' }}>
                Your Memories
              </h1>
              <p className="text-sm text-muted-foreground">
                Review your mood tracking journey
              </p>
            </div>
          </div>

          {/* Calendar */}
          <div className="space-y-6">
            <div className="flex justify-center relative">
              <div className="scale-110 transform">
                <Calendar
                  mode="single"
                  selected={selectedDate}
                  onSelect={setSelectedDate}
                  className="rounded-md border photo-calendar"
                  modifiers={{
                    hasEntry: (date) => hasEntryForDate(date) && !hasPhotoForDate(date),
                    hasPhoto: (date) => hasPhotoForDate(date)
                  }}
                  modifiersStyles={{
                    hasEntry: {
                      backgroundColor: 'hsl(var(--primary))',
                      color: 'hsl(var(--primary-foreground))',
                      borderRadius: '50%'
                    },
                    hasPhoto: {
                      borderRadius: '50%',
                      overflow: 'hidden',
                      border: '2px solid hsl(var(--primary))',
                      background: 'transparent',
                      position: 'relative'
                    }
                  }}
                  components={{
                    DayContent: ({ date }) => {
                      const photo = getPhotoForDate(date);
                      const hasEntry = hasEntryForDate(date);
                      
                      if (photo) {
                        return (
                          <div className="relative w-full h-full flex items-center justify-center">
                            <div 
                              className="absolute inset-0 rounded-full"
                              style={{
                                backgroundImage: `url(${photo})`,
                                backgroundSize: 'cover',
                                backgroundPosition: 'center',
                                opacity: 0.85
                              }}
                            />
                            <div className="absolute inset-0 bg-gradient-to-b from-transparent via-transparent to-black/40 rounded-full" />
                            <span className="relative text-white font-semibold drop-shadow-[0_2px_4px_rgba(0,0,0,0.8)] z-10">
                              {date.getDate()}
                            </span>
                          </div>
                        );
                      }
                      
                      // Show date with dot indicator for entries without photos
                      if (hasEntry) {
                        return (
                          <div className="relative w-full h-full flex items-center justify-center">
                            <span>{date.getDate()}</span>
                            <div className="absolute bottom-0 left-1/2 -translate-x-1/2 translate-y-1 w-1 h-1 bg-primary rounded-full" />
                          </div>
                        );
                      }
                      
                      return <span>{date.getDate()}</span>;
                    }
                  }}
                />
              </div>
            </div>

            {/* Selected date details */}
            {selectedDate && (
              <div className="bg-secondary/50 rounded-lg p-4">
                <h3 className="text-lg mb-3">
                  {selectedDate.toLocaleDateString('en-US', {
                    weekday: 'long',
                    year: 'numeric',
                    month: 'long',
                    day: 'numeric'
                  })}
                </h3>
                
                {selectedEntry ? (
                  <div className="space-y-4">
                    <div className="flex items-center gap-4">
                      <div className="text-center">
                        <div className="text-3xl mb-1">{selectedEntry.emoji}</div>
                        <div className="text-sm text-muted-foreground">Mood</div>
                        <div className="font-medium">{selectedEntry.mood}/10</div>
                      </div>
                      <div className="text-center">
                        <div className="text-2xl mb-1">⭐</div>
                        <div className="text-sm text-muted-foreground">Day Rating</div>
                        <div className="font-medium">{selectedEntry.dayRating}/5</div>
                      </div>
                    </div>
                    
                    {selectedEntry.journal && (
                      <div className="border-t pt-3 space-y-3">
                        <div>
                          <div className="text-sm text-muted-foreground mb-2">Journal Prompt</div>
                          <div className="text-sm italic text-muted-foreground/90 bg-secondary/20 p-3 rounded-lg">
                            "{selectedEntry.prompt}"
                          </div>
                        </div>
                        <div>
                          <div className="text-sm text-muted-foreground mb-2">My Reflection</div>
                          <div className="text-sm leading-relaxed bg-secondary/30 p-3 rounded-lg">
                            {selectedEntry.journal}
                          </div>
                        </div>
                      </div>
                    )}
                    
                    {selectedEntry.activity && (
                      <div className="text-center pt-2">
                        <div className="text-sm text-muted-foreground mb-1">Activity</div>
                        <div className="font-medium">{selectedEntry.activity}</div>
                      </div>
                    )}
                    
                    {selectedEntry.photo && (
                      <div className="mt-4">
                        <div className="text-sm text-muted-foreground mb-2 text-center">Activity Photo</div>
                        <div className="flex justify-center">
                          <img 
                            src={selectedEntry.photo} 
                            alt={`Activity: ${selectedEntry.activity}`}
                            className="w-32 h-32 object-cover rounded-lg border-2 border-primary/20"
                          />
                        </div>
                      </div>
                    )}
                  </div>
                ) : (
                  <div className="text-center py-4">
                    <div className="text-muted-foreground">
                      No mood entry recorded for this day
                    </div>
                  </div>
                )}
              </div>
            )}


          </div>
        </div>
      </div>
    </div>
  );
}