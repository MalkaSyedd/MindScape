import React, { useState } from 'react';
import { ArrowLeft, Heart } from 'lucide-react';
import { NavigationMenu } from './NavigationMenu';
import { FeatureExplainer } from './FeatureExplainer';

const moodBasedActivities = {
  low: [ // mood 1-4
    // Self-Care & Comfort
    { title: "Take a Gentle Walk", description: "Step outside for fresh air and gentle movement", icon: "🚶‍♀️", benefit: "Boosts endorphins and provides vitamin D" },
    { title: "Practice Deep Breathing", description: "Try 5 minutes of mindful breathing exercises", icon: "🧘‍♀️", benefit: "Reduces stress and calms the nervous system" },
    { title: "Listen to Calming Music", description: "Put on your favorite soothing playlist", icon: "🎵", benefit: "Helps regulate emotions and provides comfort" },
    { title: "Take a Warm Bath", description: "Create a relaxing environment with warm water", icon: "🛁", benefit: "Physical warmth can improve emotional well-being" },
    { title: "Write in a Gratitude Journal", description: "List three things you're grateful for today", icon: "📝", benefit: "Shifts focus to positive aspects of life" },
    { title: "Make Herbal Tea", description: "Brew a comforting cup of chamomile or lavender tea", icon: "🍵", benefit: "Warm rituals provide comfort and mindfulness" },
    { title: "Do Progressive Muscle Relaxation", description: "Tense and release muscle groups throughout your body", icon: "💆‍♀️", benefit: "Releases physical tension and promotes calm" },
    { title: "Light a Scented Candle", description: "Create a peaceful atmosphere with aromatherapy", icon: "🕯️", benefit: "Soothing scents can reduce stress hormones" },
    { title: "Practice Gentle Stretching", description: "Do simple stretches to release body tension", icon: "🤸‍♀️", benefit: "Improves circulation and reduces muscle stress" },
    { title: "Read a Comfort Book", description: "Revisit a favorite book or comforting story", icon: "📚", benefit: "Familiar narratives provide emotional comfort" },
    
    // Connection & Support
    { title: "Call a Trusted Friend", description: "Reach out to someone who makes you feel supported", icon: "📞", benefit: "Connection and support can lift your spirits" },
    { title: "Send a Kind Text", description: "Reach out to someone you care about", icon: "💬", benefit: "Giving care to others can improve your own mood" },
    { title: "Video Chat with Family", description: "Connect face-to-face with loved ones", icon: "👨‍👩‍👧‍👦", benefit: "Visual connection strengthens emotional bonds" },
    { title: "Write a Letter", description: "Write to someone special, even if you don't send it", icon: "✉️", benefit: "Expression can help process emotions" },
    { title: "Join an Online Support Group", description: "Connect with others who understand your experience", icon: "🤝", benefit: "Shared experiences reduce feelings of isolation" },
    { title: "Pet Therapy", description: "Spend time with a pet or watch animal videos", icon: "🐕", benefit: "Animals provide unconditional comfort and joy" },
    { title: "Ask for a Hug", description: "Request physical comfort from someone close", icon: "🤗", benefit: "Physical touch releases oxytocin and reduces stress" },
    { title: "Share Your Feelings", description: "Talk to someone about what you're experiencing", icon: "💭", benefit: "Verbalizing emotions can provide relief and clarity" },
    { title: "Listen to Podcasts", description: "Find comforting voices discussing topics you enjoy", icon: "🎧", benefit: "Engaging content can provide distraction and comfort" },
    { title: "Watch Comfort TV", description: "Put on a familiar, comforting show or movie", icon: "📺", benefit: "Familiar content provides predictable comfort" },
    
    // Mindfulness & Reflection
    { title: "Practice Meditation", description: "Use a guided meditation app for 5-10 minutes", icon: "🧘", benefit: "Meditation reduces anxiety and promotes inner peace" },
    { title: "Try Body Scan Meditation", description: "Focus on each part of your body mindfully", icon: "🫁", benefit: "Increases body awareness and promotes relaxation" },
    { title: "Practice Loving-Kindness", description: "Send kind thoughts to yourself and others", icon: "💝", benefit: "Self-compassion practices improve emotional well-being" },
    { title: "Do Gentle Yoga", description: "Try restorative or yin yoga poses", icon: "🧘‍♀️", benefit: "Combines movement, breath, and mindfulness" },
    { title: "Practice Mindful Eating", description: "Eat a small snack very slowly and mindfully", icon: "🍎", benefit: "Mindful eating grounds you in the present moment" },
    { title: "Try Square Breathing", description: "Breathe in for 4, hold for 4, out for 4, hold for 4", icon: "⬜", benefit: "Structured breathing calms the nervous system" },
    { title: "Do a Mini Meditation", description: "Sit quietly and focus on your breath for 3 minutes", icon: "⏰", benefit: "Short practices are accessible and effective" },
    { title: "Practice Acceptance", description: "Acknowledge your current feelings without judgment", icon: "🙏", benefit: "Acceptance reduces resistance and inner conflict" },
    { title: "Try Mindful Walking", description: "Walk slowly and focus on each step", icon: "👣", benefit: "Combines gentle movement with mindfulness" },
    { title: "Use a Meditation App", description: "Try Headspace, Calm, or Insight Timer", icon: "📱", benefit: "Guided support makes meditation more accessible" },
    
    // Creative Expression
    { title: "Free Writing", description: "Write continuously for 10 minutes without stopping", icon: "✍️", benefit: "Expression helps process and release emotions" },
    { title: "Draw Your Feelings", description: "Use colors and shapes to express your current state", icon: "🎨", benefit: "Art provides non-verbal emotional expression" },
    { title: "Color in a Coloring Book", description: "Focus on the simple, repetitive task of coloring", icon: "🖍️", benefit: "Repetitive tasks can be meditative and soothing" },
    { title: "Make a Mood Board", description: "Collect images that represent how you want to feel", icon: "📌", benefit: "Visual goals can inspire positive change" },
    { title: "Write Poetry", description: "Express your feelings through verse or free form", icon: "📜", benefit: "Poetic expression can transform pain into beauty" },
    { title: "Play Gentle Music", description: "Strum a guitar, play piano, or use a music app", icon: "🎹", benefit: "Creating music can be emotionally releasing" },
    { title: "Make a Photo Collage", description: "Arrange favorite photos in a meaningful way", icon: "📷", benefit: "Reviewing positive memories can lift spirits" },
    { title: "Craft Something Simple", description: "Make something with your hands, like origami", icon: "✂️", benefit: "Creating something tangible provides accomplishment" },
    { title: "Design a Dream Space", description: "Sketch or plan your ideal relaxing environment", icon: "🏠", benefit: "Visualization can provide hope and direction" },
    { title: "Create a Playlist", description: "Curate songs that comfort or inspire you", icon: "🎶", benefit: "Music curation is active engagement with healing" },
    
    // Gentle Activities
    { title: "Tend to Plants", description: "Water plants or repot a houseplant", icon: "🪴", benefit: "Nurturing life can improve mood and purpose" },
    { title: "Organize a Small Space", description: "Tidy up one drawer or corner of a room", icon: "🗂️", benefit: "Small accomplishments build momentum" },
    { title: "Make Your Bed", description: "Create one orderly, comfortable space", icon: "🛏️", benefit: "Simple tasks provide structure and accomplishment" },
    { title: "Prepare a Healthy Snack", description: "Make something nourishing for your body", icon: "🥗", benefit: "Self-care through nutrition shows self-love" },
    { title: "Do Dishes Mindfully", description: "Focus on the warm water and repetitive motions", icon: "🧽", benefit: "Mundane tasks can become meditative" },
    { title: "Fold Laundry", description: "Focus on the texture and warmth of clean clothes", icon: "👕", benefit: "Repetitive tasks can be grounding" },
    { title: "Light Decluttering", description: "Remove just 5 items from your space", icon: "🗑️", benefit: "Clearing space can help clear the mind" },
    { title: "Gentle Cleaning", description: "Wipe down surfaces in one room", icon: "🧹", benefit: "Physical activity combined with visible results" },
    { title: "Arrange Flowers", description: "Create a small bouquet or arrangement", icon: "🌸", benefit: "Beauty creation can inspire and uplift" },
    { title: "Prepare Tea Ritual", description: "Make tea preparation a mindful ceremony", icon: "🫖", benefit: "Rituals provide structure and comfort" },
    
    // Rest & Recovery
    { title: "Take a Nap", description: "Allow yourself 20-30 minutes of rest", icon: "😴", benefit: "Rest can reset your emotional and physical state" },
    { title: "Lie in the Sun", description: "Find a sunny spot and soak up natural light", icon: "☀️", benefit: "Sunlight boosts vitamin D and mood" },
    { title: "Practice Legs Up the Wall", description: "Lie with legs elevated against a wall", icon: "🦵", benefit: "Restorative pose improves circulation and calm" },
    { title: "Use a Weighted Blanket", description: "Wrap yourself in comforting pressure", icon: "🛋️", benefit: "Deep pressure can reduce anxiety and stress" },
    { title: "Take a Mental Health Day", description: "Give yourself permission to rest completely", icon: "🏖️", benefit: "Rest is essential for emotional recovery" },
    { title: "Do Nothing Meditation", description: "Sit comfortably and simply be present", icon: "🪑", benefit: "Sometimes the best action is no action" },
    { title: "Watch Clouds", description: "Lie outside and observe the sky", icon: "☁️", benefit: "Nature observation promotes mindfulness" },
    { title: "Listen to Rain", description: "Find rain sounds or sit by a window during rain", icon: "🌧️", benefit: "Natural sounds can be deeply calming" },
    { title: "Practice Gentle Self-Massage", description: "Massage your temples, neck, or hands", icon: "👐", benefit: "Touch releases tension and shows self-care" },
    { title: "Use Essential Oils", description: "Apply or diffuse calming scents like lavender", icon: "🌿", benefit: "Aromatherapy can quickly shift mood" },
    
    // Comfort Activities
    { title: "Wear Soft Clothes", description: "Change into your most comfortable outfit", icon: "👘", benefit: "Physical comfort supports emotional comfort" },
    { title: "Make Hot Chocolate", description: "Prepare a warm, comforting drink", icon: "☕", benefit: "Warm drinks provide physical and emotional comfort" },
    { title: "Use a Heating Pad", description: "Apply gentle warmth to tense areas", icon: "🔥", benefit: "Heat therapy relaxes muscles and mind" },
    { title: "Create a Comfort Kit", description: "Gather items that bring you peace", icon: "🧸", benefit: "Preparation helps you care for future difficult moments" },
    { title: "Practice Gentle Affirmations", description: "Speak kindly to yourself", icon: "💭", benefit: "Self-compassion builds resilience" },
    { title: "Look at Baby Animals", description: "Browse cute animal pictures or videos", icon: "🐣", benefit: "Cuteness triggers positive emotions" },
    { title: "Smell Something Pleasant", description: "Find a scent that brings you joy", icon: "👃", benefit: "Scent directly connects to emotional memory" },
    { title: "Hold a Comfort Object", description: "Keep something soft or meaningful close", icon: "🧸", benefit: "Physical comfort objects provide emotional security" },
    { title: "Practice Self-Forgiveness", description: "Release self-criticism for today", icon: "💚", benefit: "Self-compassion is essential for healing" },
    { title: "Create a Calm Environment", description: "Dim lights, reduce noise, make space peaceful", icon: "🕯️", benefit: "Environment greatly affects emotional state" },
    
    // Gentle Movement
    { title: "Do Tai Chi", description: "Practice slow, flowing movements", icon: "🥋", benefit: "Gentle movement meditation calms mind and body" },
    { title: "Try Qigong", description: "Practice energy cultivation exercises", icon: "🌸", benefit: "Ancient practices promote balance and peace" },
    { title: "Do Chair Exercises", description: "Simple movements you can do while seated", icon: "🪑", benefit: "Accessible movement when energy is low" },
    { title: "Practice Neck Rolls", description: "Slowly roll your neck to release tension", icon: "🔄", benefit: "Releases physical stress that affects mood" },
    { title: "Do Shoulder Shrugs", description: "Lift and release shoulder tension", icon: "🤷‍♀️", benefit: "Simple movements can provide immediate relief" },
    { title: "Gentle Spinal Twists", description: "Slowly twist your spine while seated", icon: "🌀", benefit: "Spinal movement promotes nervous system health" },
    { title: "Practice Ankle Circles", description: "Move your feet in slow circles", icon: "⭕", benefit: "Gentle movement improves circulation" },
    { title: "Do Gentle Side Bends", description: "Slowly bend from side to side", icon: "🌙", benefit: "Lateral movement can be soothing" },
    { title: "Practice Gentle Back Bends", description: "Open your chest slowly and mindfully", icon: "🌉", benefit: "Heart opening can improve mood" },
    { title: "Try Walking Meditation", description: "Walk very slowly with full attention", icon: "👣", benefit: "Combines movement with mindfulness" },
    
    // Sensory Comfort
    { title: "Touch Different Textures", description: "Explore soft, smooth, or interesting textures", icon: "🤲", benefit: "Sensory input can ground you in the present" },
    { title: "Listen to Nature Sounds", description: "Play ocean waves, forest sounds, or bird songs", icon: "🌊", benefit: "Natural sounds are inherently calming" },
    { title: "Practice Ice Cube Therapy", description: "Hold ice to stimulate the nervous system", icon: "🧊", benefit: "Cold can interrupt negative thought spirals" },
    { title: "Use a Stress Ball", description: "Squeeze and release repetitively", icon: "⚽", benefit: "Physical tension release can reduce mental tension" },
    { title: "Try Temperature Therapy", description: "Alternate between warm and cool sensations", icon: "🌡️", benefit: "Temperature changes can shift mood states" },
    { title: "Practice Deep Pressure", description: "Use pillows or blankets for comforting weight", icon: "🛏️", benefit: "Pressure therapy calms the nervous system" },
    { title: "Smell Calming Scents", description: "Use lavender, vanilla, or your favorite scent", icon: "🌺", benefit: "Scent bypasses thinking brain to affect emotions" },
    { title: "Listen to White Noise", description: "Use consistent sound to mask disturbing thoughts", icon: "📻", benefit: "Steady sounds can promote focus and calm" },
    { title: "Practice Grounding Techniques", description: "Name 5 things you see, 4 you hear, 3 you touch", icon: "🌍", benefit: "Grounding connects you to the present moment" },
    { title: "Use Fidget Tools", description: "Keep hands busy with simple, repetitive movements", icon: "🔄", benefit: "Repetitive motion can be soothing" },
    
    // Spiritual & Meaning
    { title: "Practice Gratitude", description: "Write or think of things you appreciate", icon: "🙏", benefit: "Gratitude shifts focus to positive aspects of life" },
    { title: "Read Inspirational Quotes", description: "Find words that resonate with your experience", icon: "💭", benefit: "Wisdom from others can provide comfort and hope" },
    { title: "Practice Prayer", description: "Connect with your spiritual beliefs", icon: "🕊️", benefit: "Spiritual connection can provide peace and meaning" },
    { title: "Do Acts of Self-Kindness", description: "Treat yourself with the same care you'd give a friend", icon: "💝", benefit: "Self-compassion builds emotional resilience" },
    { title: "Connect with Nature", description: "Step outside or look at natural scenes", icon: "🌳", benefit: "Nature connection has profound mood benefits" },
    { title: "Practice Mindful Observation", description: "Study one object or scene very carefully", icon: "👁️", benefit: "Deep attention can be meditative" },
    { title: "Read Spiritual Texts", description: "Find comfort in meaningful writings", icon: "📖", benefit: "Spiritual wisdom can provide perspective" },
    { title: "Practice Compassion Meditation", description: "Send loving thoughts to yourself and others", icon: "❤️", benefit: "Compassion practices improve emotional well-being" },
    { title: "Create Sacred Space", description: "Arrange a peaceful area for reflection", icon: "🕯️", benefit: "Sacred spaces support inner work" },
    { title: "Practice Presence", description: "Simply be fully present in this moment", icon: "⭐", benefit: "Presence is the foundation of all healing" },
    
    // Simple Pleasures
    { title: "Watch Sunrise or Sunset", description: "Witness the beauty of natural transitions", icon: "🌅", benefit: "Natural beauty can inspire and uplift" },
    { title: "Enjoy a Favorite Treat", description: "Mindfully eat something you love", icon: "🍫", benefit: "Small pleasures can brighten difficult moments" },
    { title: "Listen to ASMR", description: "Use autonomous sensory meridian response videos", icon: "🎧", benefit: "ASMR can be deeply relaxing and comforting" },
    { title: "Look at Art", description: "Browse beautiful images or visit virtual museums", icon: "🖼️", benefit: "Beauty can lift spirits and provide inspiration" },
    { title: "Practice Slow Breathing", description: "Breathe slower than normal for a few minutes", icon: "💨", benefit: "Slow breathing activates relaxation response" },
    { title: "Hold Something Smooth", description: "Find a smooth stone, shell, or object to hold", icon: "🪨", benefit: "Tactile comfort can be grounding" },
    { title: "Watch Fish or Aquarium", description: "Observe peaceful, repetitive movement", icon: "🐠", benefit: "Watching fish has proven stress-reduction benefits" },
    { title: "Practice Gentle Humming", description: "Hum a favorite tune or make soothing sounds", icon: "🎵", benefit: "Vibration from humming can be calming" },
    { title: "Use a Rocking Chair", description: "The gentle motion can be soothing", icon: "🪑", benefit: "Rhythmic motion activates relaxation response" },
    { title: "Practice Slow Eating", description: "Eat one thing very slowly and mindfully", icon: "🍯", benefit: "Mindful eating is a form of meditation" },
    
    // Support & Resources
    { title: "Research Therapists", description: "Look for professional support in your area", icon: "👨‍⚕️", benefit: "Professional help can provide tools and support" },
    { title: "Call a Crisis Hotline", description: "Reach out for immediate support if needed", icon: "📞", benefit: "Crisis support is available 24/7" },
    { title: "Join Online Communities", description: "Find others who understand your experience", icon: "💻", benefit: "Community connection reduces isolation" },
    { title: "Practice Self-Advocacy", description: "Ask for what you need from others", icon: "📢", benefit: "Asking for help is a sign of strength" },
    { title: "Create a Support List", description: "Write down people you can call for help", icon: "📋", benefit: "Preparation makes reaching out easier" },
    { title: "Research Mental Health Resources", description: "Learn about available help in your area", icon: "🔍", benefit: "Knowledge empowers you to get help" },
    { title: "Practice Saying No", description: "Set gentle boundaries to protect your energy", icon: "🛑", benefit: "Boundaries are essential for mental health" },
    { title: "Use Mental Health Apps", description: "Try apps designed for mood tracking and support", icon: "📱", benefit: "Technology can provide accessible support" },
    { title: "Plan for Future Difficult Days", description: "Create a self-care plan for bad days", icon: "📅", benefit: "Preparation helps you care for yourself" },
    { title: "Practice Asking for Help", description: "Reach out to someone for small assistance", icon: "🤝", benefit: "Asking for help builds connection and support" },
    
    // Memory & Reflection
    { title: "Look at Happy Photos", description: "Browse pictures from good times in your life", icon: "📸", benefit: "Positive memories can improve current mood" },
    { title: "Write About Good Memories", description: "Record a happy memory in detail", icon: "📓", benefit: "Reliving positive experiences extends their benefit" },
    { title: "Practice Memory Gratitude", description: "Be grateful for past positive experiences", icon: "🧠", benefit: "Gratitude for memories enhances their power" },
    { title: "Create a Memory Box", description: "Collect items that represent good times", icon: "📦", benefit: "Physical reminders of joy can be comforting" },
    { title: "Write Letters to Past Self", description: "Send compassion to your younger self", icon: "💌", benefit: "Self-compassion across time heals old wounds" },
    { title: "Practice Memory Meditation", description: "Sit with a positive memory and feel its emotions", icon: "🧘‍♀️", benefit: "Memory meditation can evoke positive emotions" },
    { title: "Share a Good Memory", description: "Tell someone about a happy time", icon: "💬", benefit: "Sharing good memories amplifies their power" },
    { title: "Visit a Meaningful Place", description: "Go somewhere that holds positive memories", icon: "📍", benefit: "Places can trigger positive emotional memories" },
    { title: "Practice Ancestor Gratitude", description: "Feel grateful for those who came before you", icon: "🌳", benefit: "Connection to lineage can provide strength" },
    { title: "Create Timeline of Growth", description: "Document how you've overcome challenges before", icon: "📈", benefit: "Seeing your resilience builds confidence" },
    
    // Basic Self-Care
    { title: "Brush Your Teeth", description: "Complete this basic self-care task", icon: "🪥", benefit: "Small self-care acts build momentum" },
    { title: "Wash Your Face", description: "Use cool water to refresh yourself", icon: "💧", benefit: "Physical refreshment can improve mood" },
    { title: "Change Your Clothes", description: "Put on fresh, clean clothing", icon: "👕", benefit: "Fresh clothes can help you feel renewed" },
    { title: "Drink Water", description: "Hydrate your body mindfully", icon: "💧", benefit: "Dehydration affects mood and energy" },
    { title: "Eat Something Nourishing", description: "Give your body fuel it needs", icon: "🥗", benefit: "Nutrition directly affects brain function" },
    { title: "Take Vitamins", description: "Support your body's nutritional needs", icon: "💊", benefit: "Nutritional support aids mental health" },
    { title: "Practice Good Posture", description: "Sit or stand with spine aligned", icon: "🧍‍♀️", benefit: "Posture affects mood and confidence" },
    { title: "Get Fresh Air", description: "Open windows or step outside briefly", icon: "🌬️", benefit: "Fresh air improves alertness and mood" },
    { title: "Adjust Lighting", description: "Optimize your environment's brightness", icon: "💡", benefit: "Light affects circadian rhythms and mood" },
    { title: "Set Up for Rest", description: "Prepare your space for quality sleep", icon: "🛏️", benefit: "Sleep preparation supports better rest" },
    
    // Gentle Learning
    { title: "Watch Educational Videos", description: "Learn something interesting at your own pace", icon: "📺", benefit: "Learning provides sense of growth and accomplishment" },
    { title: "Read One Article", description: "Choose something that interests you", icon: "📰", benefit: "Engaging your mind in low-pressure learning" },
    { title: "Practice a New Word", description: "Learn one new word in any language", icon: "📝", benefit: "Small learning goals are achievable and rewarding" },
    { title: "Listen to Gentle Podcasts", description: "Find soothing, interesting content", icon: "🎧", benefit: "Passive learning can be comforting" },
    { title: "Practice Counting", description: "Count backwards from 100 or count objects", icon: "🔢", benefit: "Simple mental tasks can be grounding" },
    { title: "Try Memory Games", description: "Use gentle brain training exercises", icon: "🧩", benefit: "Mental stimulation can improve mood" },
    { title: "Practice Visualization", description: "Imagine peaceful, safe places", icon: "🏞️", benefit: "Visualization can provide mental escape" },
    { title: "Learn Breathing Patterns", description: "Try different breathing techniques", icon: "💨", benefit: "Breath control tools are always available" },
    { title: "Study Cloud Formations", description: "Learn about different types of clouds", icon: "☁️", benefit: "Nature study can be meditative" },
    { title: "Practice Letter Writing", description: "Write the alphabet slowly and mindfully", icon: "✍️", benefit: "Repetitive writing can be calming" },
    
    // Emotional Processing
    { title: "Name Your Emotions", description: "Identify and label what you're feeling", icon: "🏷️", benefit: "Naming emotions helps process them" },
    { title: "Rate Your Feelings", description: "Put numbers to emotions from 1-10", icon: "📊", benefit: "Quantifying feelings provides perspective" },
    { title: "Practice Emotional Acceptance", description: "Allow feelings to exist without fighting them", icon: "🤲", benefit: "Acceptance reduces emotional struggle" },
    { title: "Write Emotion Letters", description: "Write to your emotions as if they were people", icon: "💌", benefit: "Personifying emotions can provide insight" },
    { title: "Practice Emotion Breathing", description: "Breathe into your emotional center", icon: "❤️‍🩹", benefit: "Breathing through emotions helps them move" },
    { title: "Use Emotion Words", description: "Expand your vocabulary for feelings", icon: "📚", benefit: "Better emotional vocabulary improves processing" },
    { title: "Practice Feeling Meditation", description: "Sit with emotions without trying to change them", icon: "🧘", benefit: "Sitting with feelings helps them naturally shift" },
    { title: "Create Emotion Art", description: "Express feelings through color and form", icon: "🎨", benefit: "Art provides non-verbal emotional expression" },
    { title: "Talk to Your Emotions", description: "Have a conversation with your feelings", icon: "💭", benefit: "Dialogue with emotions provides insight" },
    { title: "Practice Emotion Release", description: "Imagine letting feelings flow through you", icon: "🌊", benefit: "Visualization can help emotions move naturally" },
    
    // Simple Rituals
    { title: "Light Incense", description: "Create atmosphere with gentle smoke and scent", icon: "🪔", benefit: "Rituals provide structure and comfort" },
    { title: "Ring a Bell", description: "Use sound to mark this moment", icon: "🔔", benefit: "Sound can shift energy and attention" },
    { title: "Pour Water Mindfully", description: "Focus completely on the act of pouring", icon: "🫗", benefit: "Simple actions become meditation" },
    { title: "Arrange Objects", description: "Organize items in a pleasing way", icon: "🎯", benefit: "Creating order can provide mental calm" },
    { title: "Practice Door Rituals", description: "Pause mindfully when passing through doorways", icon: "🚪", benefit: "Transition rituals help mark mental shifts" },
    { title: "Use Prayer Beads", description: "Count beads while focusing on breath or words", icon: "📿", benefit: "Repetitive counting can be meditative" },
    { title: "Create Morning Ritual", description: "Establish one meaningful morning practice", icon: "🌅", benefit: "Morning rituals set positive tone for day" },
    { title: "Practice Evening Ritual", description: "Create one soothing end-of-day practice", icon: "🌙", benefit: "Evening rituals promote better rest" },
    { title: "Use Transition Rituals", description: "Mark changes in your day with mindful pauses", icon: "⏳", benefit: "Rituals help process life transitions" },
    { title: "Practice Gratitude Ritual", description: "Create ceremony around appreciating life", icon: "🙏", benefit: "Gratitude rituals amplify positive feelings" }
  ],
  
  medium: [ // mood 5-7
    // Physical Activity
    { title: "Go for a Nature Walk", description: "Explore a park or natural area nearby", icon: "🌳", benefit: "Nature connection improves mood and energy" },
    { title: "Do Light Exercise", description: "Try yoga, stretching, or a fun workout", icon: "🤸‍♀️", benefit: "Physical activity releases mood-boosting chemicals" },
    { title: "Try Dancing", description: "Put on music and move your body freely", icon: "💃", benefit: "Dancing combines exercise with joy and expression" },
    { title: "Go Swimming", description: "Enjoy the water for exercise and relaxation", icon: "🏊‍♀️", benefit: "Swimming is full-body exercise with meditative qualities" },
    { title: "Ride a Bike", description: "Cycle around your neighborhood or on trails", icon: "🚴‍♀️", benefit: "Cycling provides exercise and sense of adventure" },
    { title: "Play Frisbee", description: "Toss a frisbee in a park or yard", icon: "🥏", benefit: "Playful activity combines movement with fun" },
    { title: "Try Rock Climbing", description: "Indoor or outdoor climbing for challenge", icon: "🧗‍♀️", benefit: "Climbing builds confidence and provides accomplishment" },
    { title: "Go Bowling", description: "Enjoy this accessible sport with friends", icon: "🎳", benefit: "Social activity with achievable goals" },
    { title: "Play Miniature Golf", description: "Fun, low-pressure outdoor activity", icon: "⛳", benefit: "Playful competition with immediate feedback" },
    { title: "Try Skateboarding", description: "Learn or practice skateboard skills", icon: "🛹", benefit: "Balance challenges build confidence" },
    { title: "Go Sledding", description: "If it's winter, enjoy snow activities", icon: "🛷", benefit: "Seasonal activities connect you to natural cycles" },
    { title: "Play Tennis", description: "Hit balls against a wall or with a partner", icon: "🎾", benefit: "Racquet sports provide great exercise and focus" },
    { title: "Try Martial Arts", description: "Practice basic moves or take a class", icon: "🥋", benefit: "Martial arts build discipline and confidence" },
    { title: "Go Hiking", description: "Take a longer walk on trails", icon: "🥾", benefit: "Hiking combines exercise with nature immersion" },
    { title: "Play Basketball", description: "Shoot hoops alone or with others", icon: "🏀", benefit: "Basketball builds coordination and provides activity" },
    { title: "Try Paddle Sports", description: "Kayaking, paddleboarding, or canoeing", icon: "🚣‍♀️", benefit: "Water sports provide unique physical challenge" },
    { title: "Go Ice Skating", description: "Try skating at a local rink", icon: "⛸️", benefit: "Balance activities challenge body and mind" },
    { title: "Practice Tai Chi", description: "Flowing martial arts in nature", icon: "🥋", benefit: "Mindful movement balances body and mind" },
    { title: "Try Parkour", description: "Practice moving efficiently through environment", icon: "🏃‍♂️", benefit: "Creative movement builds problem-solving skills" },
    { title: "Go Geocaching", description: "Use GPS to find hidden treasures", icon: "🗺️", benefit: "Treasure hunting combines adventure with technology" },
    
    // Creative Arts
    { title: "Try Creative Expression", description: "Draw, paint, write, or craft something", icon: "🎨", benefit: "Creative activities boost happiness and flow" },
    { title: "Learn a Musical Instrument", description: "Practice guitar, piano, or any instrument", icon: "🎸", benefit: "Music learning builds new neural pathways" },
    { title: "Write a Short Story", description: "Create a fictional narrative", icon: "📖", benefit: "Storytelling exercises imagination and creativity" },
    { title: "Try Photography", description: "Take artistic photos of your surroundings", icon: "📷", benefit: "Photography encourages seeing beauty everywhere" },
    { title: "Make a Video", description: "Create content about something you enjoy", icon: "🎬", benefit: "Video creation combines multiple creative skills" },
    { title: "Practice Calligraphy", description: "Learn beautiful handwriting or lettering", icon: "🖋️", benefit: "Calligraphy combines art with mindfulness" },
    { title: "Try Pottery", description: "Work with clay to create objects", icon: "🏺", benefit: "Working with clay is tactile and meditative" },
    { title: "Design Something", description: "Create graphics, websites, or layouts", icon: "💻", benefit: "Design thinking builds problem-solving skills" },
    { title: "Write Poetry", description: "Express yourself through verse", icon: "📜", benefit: "Poetry condensed emotion into beautiful language" },
    { title: "Try Improvisation", description: "Practice spontaneous creative expression", icon: "🎭", benefit: "Improv builds confidence and creativity" },
    { title: "Make Jewelry", description: "Create wearable art", icon: "💍", benefit: "Jewelry making combines creativity with fine motor skills" },
    { title: "Try Woodworking", description: "Create something useful with wood", icon: "🪵", benefit: "Working with wood is tactile and productive" },
    { title: "Practice Origami", description: "Fold paper into beautiful shapes", icon: "📋", benefit: "Origami combines precision with artistic expression" },
    { title: "Try Embroidery", description: "Create decorative stitching", icon: "🧵", benefit: "Needlework is meditative and creates beauty" },
    { title: "Make Soap or Candles", description: "Create useful items from scratch", icon: "🕯️", benefit: "Crafting useful items provides accomplishment" },
    { title: "Try Mosaic Art", description: "Create pictures from small pieces", icon: "🔲", benefit: "Mosaic work is detail-oriented and satisfying" },
    { title: "Practice Voice Training", description: "Work on singing or speaking skills", icon: "🎤", benefit: "Voice work builds confidence and expression" },
    { title: "Try Graffiti Art", description: "Practice legal street art techniques", icon: "🖌️", benefit: "Street art allows bold creative expression" },
    { title: "Make Stop-Motion Animation", description: "Create moving pictures frame by frame", icon: "🎞️", benefit: "Animation combines storytelling with technical skill" },
    { title: "Try Glass Blowing", description: "Learn this ancient art form", icon: "🌟", benefit: "Glass blowing is challenging and creates beautiful objects" },
    
    // Social Connection
    { title: "Video Call a Friend", description: "Connect face-to-face with someone you care about", icon: "💻", benefit: "Social connection enhances positive emotions" },
    { title: "Join a Club", description: "Find others who share your interests", icon: "👥", benefit: "Clubs provide community and shared purpose" },
    { title: "Attend a Meetup", description: "Go to local gatherings of like-minded people", icon: "🤝", benefit: "Meetups expand social circles and interests" },
    { title: "Volunteer", description: "Help others in your community", icon: "❤️", benefit: "Helping others creates meaning and connection" },
    { title: "Take a Class", description: "Learn something new with others", icon: "🎓", benefit: "Classes combine learning with social interaction" },
    { title: "Join a Sports Team", description: "Participate in recreational sports", icon: "⚽", benefit: "Team sports build cooperation and fitness" },
    { title: "Attend Cultural Events", description: "Go to concerts, theater, or art shows", icon: "🎭", benefit: "Cultural events inspire and connect to community" },
    { title: "Host a Gathering", description: "Invite friends over for food or activities", icon: "🏠", benefit: "Hosting strengthens relationships and community" },
    { title: "Join Online Communities", description: "Participate in forums about your interests", icon: "💬", benefit: "Online communities provide global connection" },
    { title: "Practice Public Speaking", description: "Join Toastmasters or practice presentations", icon: "🎤", benefit: "Public speaking builds confidence and connection" },
    { title: "Start a Book Club", description: "Organize regular discussions about books", icon: "📚", benefit: "Book clubs combine learning with socializing" },
    { title: "Participate in Community Service", description: "Join local improvement projects", icon: "🌟", benefit: "Community service creates belonging and purpose" },
    { title: "Attend Religious Services", description: "Connect with spiritual community", icon: "🙏", benefit: "Spiritual communities provide support and meaning" },
    { title: "Join a Hobby Group", description: "Find others who share your interests", icon: "🧩", benefit: "Hobby groups provide friendship and skill-sharing" },
    { title: "Participate in Local Politics", description: "Attend town halls or community meetings", icon: "🗳️", benefit: "Civic engagement creates sense of agency" },
    { title: "Join a Support Group", description: "Connect with others facing similar challenges", icon: "🤗", benefit: "Support groups provide understanding and coping strategies" },
    { title: "Attend Workshops", description: "Learn new skills with others", icon: "🔧", benefit: "Workshops combine skill-building with social interaction" },
    { title: "Join Gaming Groups", description: "Play board games or video games with others", icon: "🎮", benefit: "Gaming provides fun social interaction" },
    { title: "Participate in Protests", description: "Stand up for causes you believe in", icon: "✊", benefit: "Activism creates sense of purpose and community" },
    { title: "Join Professional Networks", description: "Connect with others in your field", icon: "💼", benefit: "Professional networks build career and relationships" },
    
    // Learning & Growth
    { title: "Learn Something New", description: "Watch a tutorial or read about a topic of interest", icon: "📚", benefit: "Learning creates a sense of growth and achievement" },
    { title: "Take an Online Course", description: "Enroll in structured learning", icon: "💻", benefit: "Courses provide systematic skill development" },
    { title: "Learn a New Language", description: "Practice speaking, reading, or writing", icon: "🌍", benefit: "Language learning exercises the brain and opens opportunities" },
    { title: "Study History", description: "Learn about past events and cultures", icon: "🏛️", benefit: "History provides perspective and understanding" },
    { title: "Practice Math", description: "Work on mathematical concepts or problems", icon: "🔢", benefit: "Math exercises analytical thinking" },
    { title: "Learn Science", description: "Explore physics, chemistry, or biology", icon: "🔬", benefit: "Science learning satisfies curiosity about the world" },
    { title: "Study Philosophy", description: "Explore big questions about existence", icon: "🤔", benefit: "Philosophy develops critical thinking" },
    { title: "Learn Technology Skills", description: "Practice coding, design, or digital tools", icon: "💻", benefit: "Tech skills are increasingly valuable" },
    { title: "Study Psychology", description: "Learn about human behavior and mind", icon: "🧠", benefit: "Psychology helps understand self and others" },
    { title: "Practice Typing", description: "Improve your keyboard skills", icon: "⌨️", benefit: "Better typing improves digital communication" },
    { title: "Learn First Aid", description: "Develop life-saving skills", icon: "🏥", benefit: "First aid knowledge builds confidence and helps others" },
    { title: "Study Economics", description: "Understand money and markets", icon: "💰", benefit: "Economic literacy improves financial decisions" },
    { title: "Learn Astronomy", description: "Study stars, planets, and the universe", icon: "🌌", benefit: "Astronomy provides cosmic perspective" },
    { title: "Practice Logic Puzzles", description: "Work on brain teasers and problem-solving", icon: "🧩", benefit: "Logic puzzles improve reasoning skills" },
    { title: "Study Nutrition", description: "Learn about healthy eating and body science", icon: "🥗", benefit: "Nutrition knowledge improves health choices" },
    { title: "Learn About Climate", description: "Understand environmental science", icon: "🌍", benefit: "Climate knowledge helps informed decision-making" },
    { title: "Practice Memory Techniques", description: "Learn methods to improve recall", icon: "🧠", benefit: "Memory skills enhance learning capacity" },
    { title: "Study Literature", description: "Read and analyze great works", icon: "📖", benefit: "Literature develops empathy and cultural understanding" },
    { title: "Learn About Cultures", description: "Study different ways of life around the world", icon: "🌎", benefit: "Cultural knowledge builds tolerance and understanding" },
    { title: "Practice Speed Reading", description: "Learn to read faster and more efficiently", icon: "📚", benefit: "Speed reading allows more information consumption" },
    
    // Productive Activities
    { title: "Cook a Favorite Meal", description: "Prepare something delicious and nourishing", icon: "🍳", benefit: "Accomplishment and self-care combined" },
    { title: "Organize Your Space", description: "Declutter and arrange your living area", icon: "🏠", benefit: "Organized space promotes mental clarity" },
    { title: "Plan Future Goals", description: "Set and organize your aspirations", icon: "🎯", benefit: "Goal-setting provides direction and motivation" },
    { title: "Update Your Resume", description: "Refresh your professional profile", icon: "📄", benefit: "Career maintenance builds confidence" },
    { title: "Learn Home Improvement", description: "Practice basic repair and maintenance skills", icon: "🔨", benefit: "Home skills provide independence and accomplishment" },
    { title: "Start a Garden", description: "Plant and tend to vegetables or flowers", icon: "🌱", benefit: "Gardening connects you to natural cycles" },
    { title: "Practice Time Management", description: "Organize your schedule and priorities", icon: "⏰", benefit: "Time management reduces stress and increases accomplishment" },
    { title: "Learn Budgeting", description: "Organize your finances", icon: "💰", benefit: "Financial control reduces anxiety" },
    { title: "Practice Meal Planning", description: "Plan healthy, economical meals", icon: "📋", benefit: "Meal planning saves time and improves nutrition" },
    { title: "Organize Digital Files", description: "Clean up computer and phone storage", icon: "💾", benefit: "Digital organization improves efficiency" },
    { title: "Practice Car Maintenance", description: "Learn basic vehicle care", icon: "🚗", benefit: "Car knowledge saves money and provides independence" },
    { title: "Learn Investment Basics", description: "Study financial growth strategies", icon: "📈", benefit: "Investment knowledge builds financial security" },
    { title: "Practice Emergency Preparedness", description: "Prepare for potential emergencies", icon: "🆘", benefit: "Preparedness reduces anxiety about uncertainty" },
    { title: "Learn Energy Efficiency", description: "Make your home more efficient", icon: "💡", benefit: "Efficiency saves money and helps environment" },
    { title: "Practice Professional Skills", description: "Develop job-related abilities", icon: "💼", benefit: "Skill development advances career prospects" },
    { title: "Organize Important Documents", description: "File and secure important papers", icon: "📁", benefit: "Document organization reduces stress" },
    { title: "Learn About Insurance", description: "Understand protection and coverage", icon: "🛡️", benefit: "Insurance knowledge protects your interests" },
    { title: "Practice Negotiation", description: "Learn to advocate for yourself", icon: "🤝", benefit: "Negotiation skills improve life outcomes" },
    { title: "Study Your Industry", description: "Stay current with your field", icon: "📊", benefit: "Industry knowledge advances career" },
    { title: "Practice Project Management", description: "Learn to organize complex tasks", icon: "📅", benefit: "Project skills improve efficiency" },
    
    // Adventure & Exploration
    { title: "Explore Your City", description: "Visit new neighborhoods or attractions", icon: "🗺️", benefit: "Exploration builds appreciation for your environment" },
    { title: "Try New Restaurants", description: "Experience different cuisines", icon: "🍽️", benefit: "New foods expand palate and experience" },
    { title: "Visit Museums", description: "Explore art, history, or science exhibitions", icon: "🏛️", benefit: "Museums provide learning and inspiration" },
    { title: "Go to Farmers Markets", description: "Explore local produce and crafts", icon: "🥕", benefit: "Local markets connect you to community" },
    { title: "Take Day Trips", description: "Visit nearby towns or attractions", icon: "🚗", benefit: "Day trips provide adventure without major commitment" },
    { title: "Try Geocaching", description: "Use GPS to find hidden treasures", icon: "📱", benefit: "Geocaching combines technology with outdoor adventure" },
    { title: "Visit Libraries", description: "Explore books and community resources", icon: "📚", benefit: "Libraries provide free learning and community" },
    { title: "Attend Free Events", description: "Find local festivals and gatherings", icon: "🎪", benefit: "Free events provide entertainment and community" },
    { title: "Explore Nature Areas", description: "Visit parks, beaches, or wilderness", icon: "🌲", benefit: "Nature exploration improves mental health" },
    { title: "Try Different Transportation", description: "Take trains, buses, or bike routes", icon: "🚌", benefit: "New transportation provides different perspectives" },
    { title: "Visit Historical Sites", description: "Learn about local or regional history", icon: "🏰", benefit: "History sites provide context and perspective" },
    { title: "Go Antiquing", description: "Browse vintage and antique stores", icon: "🕰️", benefit: "Antiquing is treasure hunting and history exploration" },
    { title: "Attend Sporting Events", description: "Watch local teams play", icon: "🏟️", benefit: "Sports events provide excitement and community" },
    { title: "Try New Hiking Trails", description: "Explore different outdoor paths", icon: "🥾", benefit: "New trails provide exercise and discovery" },
    { title: "Visit Observation Decks", description: "See your area from new heights", icon: "🏢", benefit: "Height provides new perspective on familiar places" },
    { title: "Explore College Campuses", description: "Walk through nearby universities", icon: "🎓", benefit: "Campuses provide inspiring learning environments" },
    { title: "Try Urban Photography", description: "Capture interesting city scenes", icon: "📷", benefit: "Photography encourages seeing familiar places differently" },
    { title: "Visit Specialty Shops", description: "Explore unique local businesses", icon: "🛍️", benefit: "Specialty shops support local economy and provide discovery" },
    { title: "Attend Lectures", description: "Go to talks about interesting topics", icon: "👨‍🏫", benefit: "Lectures provide learning and intellectual stimulation" },
    { title: "Try New Coffee Shops", description: "Work or relax in different environments", icon: "☕", benefit: "Coffee shops provide community and inspiration" },
    
    // Health & Wellness
    { title: "Practice Yoga", description: "Follow online classes or attend studio", icon: "🧘‍♀️", benefit: "Yoga improves flexibility and mental calm" },
    { title: "Try Meditation", description: "Practice different meditation techniques", icon: "🧘", benefit: "Meditation reduces stress and improves focus" },
    { title: "Get a Massage", description: "Professional or self-massage for tension relief", icon: "💆‍♀️", benefit: "Massage reduces physical and mental stress" },
    { title: "Practice Breathing Exercises", description: "Learn advanced breathing techniques", icon: "💨", benefit: "Breath control improves stress management" },
    { title: "Try Acupuncture", description: "Explore traditional Chinese medicine", icon: "📌", benefit: "Acupuncture can reduce pain and stress" },
    { title: "Practice Stretching", description: "Do comprehensive flexibility routines", icon: "🤸‍♀️", benefit: "Stretching improves mobility and reduces tension" },
    { title: "Try Sauna or Hot Tub", description: "Use heat therapy for relaxation", icon: "🔥", benefit: "Heat therapy improves circulation and relaxation" },
    { title: "Practice Sleep Hygiene", description: "Improve your sleep environment and habits", icon: "😴", benefit: "Better sleep improves all aspects of health" },
    { title: "Try Cold Therapy", description: "Use cold showers or ice baths", icon: "🧊", benefit: "Cold therapy can boost mood and energy" },
    { title: "Practice Posture Improvement", description: "Work on alignment and body mechanics", icon: "🧍‍♀️", benefit: "Good posture reduces pain and improves confidence" },
    { title: "Learn About Nutrition", description: "Study healthy eating principles", icon: "🥗", benefit: "Nutrition knowledge improves health and energy" },
    { title: "Try Different Teas", description: "Explore herbal and traditional teas", icon: "🍵", benefit: "Tea provides hydration and various health benefits" },
    { title: "Practice Mindful Eating", description: "Eat slowly and pay attention to food", icon: "🍎", benefit: "Mindful eating improves digestion and satisfaction" },
    { title: "Try Supplements", description: "Research and try beneficial vitamins", icon: "💊", benefit: "Proper supplementation can improve health" },
    { title: "Practice Progressive Relaxation", description: "Systematically relax all muscle groups", icon: "😌", benefit: "Progressive relaxation reduces overall tension" },
    { title: "Learn About Mental Health", description: "Study psychology and emotional wellness", icon: "🧠", benefit: "Mental health knowledge improves self-care" },
    { title: "Try Alternative Medicine", description: "Explore holistic health approaches", icon: "🌿", benefit: "Alternative approaches may complement traditional medicine" },
    { title: "Practice Gratitude", description: "Develop daily appreciation practices", icon: "🙏", benefit: "Gratitude practices improve overall life satisfaction" },
    { title: "Try Energy Healing", description: "Explore reiki, chakra work, or similar practices", icon: "✨", benefit: "Energy work can promote relaxation and well-being" },
    { title: "Practice Mindfulness", description: "Bring full attention to present moments", icon: "🎯", benefit: "Mindfulness reduces anxiety and improves focus" },
    
    // Creative Problem Solving
    { title: "Practice Brainstorming", description: "Generate ideas for personal or work projects", icon: "💡", benefit: "Brainstorming builds creative thinking skills" },
    { title: "Try Mind Mapping", description: "Visualize ideas and connections", icon: "🕸️", benefit: "Mind mapping improves organization and creativity" },
    { title: "Practice Innovation", description: "Think of improvements to everyday objects", icon: "⚙️", benefit: "Innovation thinking builds problem-solving skills" },
    { title: "Design Solutions", description: "Identify problems and create solutions", icon: "🔧", benefit: "Solution-focused thinking improves life satisfaction" },
    { title: "Practice Lateral Thinking", description: "Approach problems from unusual angles", icon: "🔄", benefit: "Lateral thinking expands problem-solving options" },
    { title: "Try Invention", description: "Create new tools or improve existing ones", icon: "🛠️", benefit: "Invention combines creativity with practical skills" },
    { title: "Practice Systems Thinking", description: "Look at how parts connect to wholes", icon: "🔗", benefit: "Systems thinking improves understanding of complexity" },
    { title: "Learn Design Thinking", description: "Use structured creative problem-solving", icon: "📐", benefit: "Design thinking provides frameworks for innovation" },
    { title: "Try Reverse Engineering", description: "Take apart objects to understand how they work", icon: "🔍", benefit: "Reverse engineering builds analytical skills" },
    { title: "Practice Pattern Recognition", description: "Look for patterns in data, nature, or behavior", icon: "🔄", benefit: "Pattern recognition improves prediction and understanding" },
    { title: "Learn About Complexity", description: "Study how complex systems emerge and function", icon: "🌐", benefit: "Complexity understanding helps navigate modern life" },
    { title: "Practice Synthesis", description: "Combine different ideas into new concepts", icon: "⚗️", benefit: "Synthesis builds ability to create new knowledge" },
    { title: "Try Scenario Planning", description: "Imagine different possible futures", icon: "🔮", benefit: "Scenario planning improves preparedness and adaptability" },
    { title: "Practice Analogical Thinking", description: "Use analogies to understand new concepts", icon: "↔️", benefit: "Analogical thinking improves learning and communication" },
    { title: "Learn About Emergence", description: "Study how new properties arise from simple rules", icon: "🌟", benefit: "Emergence understanding reveals hidden patterns" },
    { title: "Try Constraint-Based Design", description: "Create solutions within specific limitations", icon: "📏", benefit: "Constraints can spark creativity and innovation" },
    { title: "Practice Abstract Thinking", description: "Work with concepts and ideas rather than concrete objects", icon: "🎭", benefit: "Abstract thinking improves intellectual flexibility" },
    { title: "Learn About Networks", description: "Study how connections create powerful systems", icon: "🕷️", benefit: "Network thinking reveals hidden relationships" },
    { title: "Try Biomimicry", description: "Learn from nature to solve human problems", icon: "🦋", benefit: "Biomimicry combines science with creative innovation" },
    { title: "Practice Future Thinking", description: "Imagine and plan for different possible futures", icon: "🚀", benefit: "Future thinking improves planning and adaptability" }
  ],
  
  high: [ // mood 8-10
    // High Energy Activities
    { title: "Exercise with Intensity", description: "Go for a run, dance, or do energetic movement", icon: "🏃‍♀️", benefit: "Channels high energy into physical vitality" },
    { title: "Try Rock Climbing", description: "Challenge yourself with indoor or outdoor climbing", icon: "🧗‍♀️", benefit: "Climbing builds strength, confidence, and focus" },
    { title: "Go for a Long Bike Ride", description: "Explore new areas on two wheels", icon: "🚴‍♀️", benefit: "Cycling provides adventure and excellent cardiovascular exercise" },
    { title: "Try High-Intensity Training", description: "Push your physical limits with intense workouts", icon: "💪", benefit: "HIIT maximizes fitness gains and endorphin release" },
    { title: "Practice Martial Arts", description: "Train in karate, boxing, or other fighting arts", icon: "🥊", benefit: "Martial arts build discipline, confidence, and physical skill" },
    { title: "Go Snowboarding or Skiing", description: "Hit the slopes for winter sports", icon: "🏂", benefit: "Winter sports provide adrenaline and seasonal joy" },
    { title: "Try Parkour", description: "Learn to move efficiently through urban environments", icon: "🏃‍♂️", benefit: "Parkour builds creativity, strength, and spatial awareness" },
    { title: "Go Surfing", description: "Ride waves and connect with ocean energy", icon: "🏄‍♀️", benefit: "Surfing combines athleticism with nature connection" },
    { title: "Try Crossfit", description: "Join high-intensity functional fitness training", icon: "🏋️‍♀️", benefit: "Crossfit builds total-body fitness and community" },
    { title: "Go Mountain Biking", description: "Navigate challenging terrain on trails", icon: "🚵‍♂️", benefit: "Mountain biking combines adventure with intense exercise" },
    { title: "Try Obstacle Races", description: "Train for or participate in obstacle courses", icon: "🏃‍♀️", benefit: "Obstacle races build problem-solving and fitness" },
    { title: "Practice Acrobatics", description: "Learn flips, handstands, and aerial movements", icon: "🤸‍♂️", benefit: "Acrobatics builds strength, coordination, and confidence" },
    { title: "Go White Water Rafting", description: "Navigate rapids for adventure and teamwork", icon: "🚣‍♂️", benefit: "Rafting provides adrenaline and group bonding" },
    { title: "Try Bungee Jumping", description: "Take the ultimate leap of faith", icon: "🪂", benefit: "Extreme sports build courage and create peak experiences" },
    { title: "Practice Sprinting", description: "Work on speed and explosive power", icon: "💨", benefit: "Sprinting builds power and releases intense energy" },
    { title: "Try Competitive Sports", description: "Join leagues or tournaments in your favorite sport", icon: "🏆", benefit: "Competition channels energy and builds achievement" },
    { title: "Go Trail Running", description: "Run through natural landscapes", icon: "🏞️", benefit: "Trail running combines fitness with nature immersion" },
    { title: "Practice Gymnastics", description: "Learn tumbling, apparatus work, or flexibility", icon: "🤸‍♀️", benefit: "Gymnastics builds total-body strength and grace" },
    { title: "Try Adventure Racing", description: "Combine multiple sports in one event", icon: "🏃‍♀️", benefit: "Adventure racing provides ultimate physical and mental challenge" },
    { title: "Go Skydiving", description: "Experience the ultimate adrenaline rush", icon: "🪂", benefit: "Skydiving creates unforgettable peak experiences" },
    
    // Creative & Ambitious Projects
    { title: "Create and Share", description: "Make something and share it with others", icon: "📸", benefit: "Expressing creativity spreads joy to others" },
    { title: "Start a Blog or Vlog", description: "Share your thoughts and experiences online", icon: "📝", benefit: "Content creation builds audience and influence" },
    { title: "Launch a Business", description: "Turn an idea into a real venture", icon: "🚀", benefit: "Entrepreneurship builds independence and impact" },
    { title: "Write a Book", description: "Begin or continue a major writing project", icon: "📚", benefit: "Book writing creates lasting impact and accomplishment" },
    { title: "Create a Documentary", description: "Film a story that matters to you", icon: "🎬", benefit: "Documentary making combines creativity with social impact" },
    { title: "Start a Podcast", description: "Share ideas through audio content", icon: "🎙️", benefit: "Podcasting builds communication skills and audience" },
    { title: "Create an App", description: "Build software that solves problems", icon: "📱", benefit: "App development combines creativity with technical skill" },
    { title: "Design a Website", description: "Build online presence for yourself or others", icon: "💻", benefit: "Web design combines art with functionality" },
    { title: "Create Art Installation", description: "Make large-scale artistic statement", icon: "🎨", benefit: "Installations create powerful public impact" },
    { title: "Start a YouTube Channel", description: "Create video content around your passions", icon: "📹", benefit: "Video creation builds technical and creative skills" },
    { title: "Launch a Nonprofit", description: "Create organization around cause you care about", icon: "❤️", benefit: "Nonprofits create systematic positive impact" },
    { title: "Create a Game", description: "Design board games, video games, or puzzles", icon: "🎮", benefit: "Game design builds systems thinking and creativity" },
    { title: "Start a Movement", description: "Organize others around important cause", icon: "✊", benefit: "Movements create social change and leadership experience" },
    { title: "Create Educational Content", description: "Teach others what you know", icon: "🎓", benefit: "Teaching reinforces learning and helps others grow" },
    { title: "Design Products", description: "Invent useful objects or improve existing ones", icon: "💡", benefit: "Product design combines creativity with problem-solving" },
    { title: "Create Music Album", description: "Record and produce original music", icon: "🎵", benefit: "Music creation provides deep creative satisfaction" },
    { title: "Write Screenplay", description: "Create scripts for film or television", icon: "🎭", benefit: "Screenwriting combines storytelling with visual thinking" },
    { title: "Create Online Course", description: "Package your knowledge into structured learning", icon: "💻", benefit: "Course creation helps others while building passive income" },
    { title: "Start a Magazine", description: "Curate and publish content around topics you love", icon: "📰", benefit: "Publishing builds editorial and business skills" },
    { title: "Create Public Art", description: "Make art that transforms public spaces", icon: "🏛️", benefit: "Public art creates lasting community impact" },
    
    // Leadership & Impact
    { title: "Share Your Energy", description: "Help someone or volunteer for a cause you care about", icon: "🤝", benefit: "Giving back amplifies positive feelings" },
    { title: "Organize an Event", description: "Plan gathering that brings people together", icon: "🎪", benefit: "Event organizing builds leadership and community" },
    { title: "Mentor Someone", description: "Guide others in areas where you have experience", icon: "👨‍🏫", benefit: "Mentoring creates legacy and helps others grow" },
    { title: "Lead a Team", description: "Take charge of group project or initiative", icon: "👥", benefit: "Leadership builds confidence and impact" },
    { title: "Start a Fundraiser", description: "Raise money for causes you care about", icon: "💰", benefit: "Fundraising combines social skills with impact" },
    { title: "Become an Activist", description: "Campaign for social or political change", icon: "📢", benefit: "Activism channels passion into positive change" },
    { title: "Teach or Train Others", description: "Share your skills and knowledge", icon: "🏫", benefit: "Teaching reinforces learning and creates impact" },
    { title: "Start a Support Group", description: "Create space for others with shared challenges", icon: "🤗", benefit: "Support groups help others while building leadership" },
    { title: "Become a Coach", description: "Help others achieve their goals", icon: "🏃‍♂️", benefit: "Coaching builds interpersonal skills and impact" },
    { title: "Run for Office", description: "Seek political position to create change", icon: "🗳️", benefit: "Public office provides platform for systematic change" },
    { title: "Start a Club", description: "Create community around shared interests", icon: "🎯", benefit: "Clubs build leadership and bring people together" },
    { title: "Organize Volunteers", description: "Coordinate others for community service", icon: "👥", benefit: "Volunteer coordination multiplies individual impact" },
    { title: "Create Scholarship Fund", description: "Help others access education", icon: "🎓", benefit: "Scholarships create lasting educational impact" },
    { title: "Build Community Garden", description: "Organize neighbors around food production", icon: "🌱", benefit: "Community gardens build relationships and sustainability" },
    { title: "Start Neighborhood Watch", description: "Organize community safety initiative", icon: "👁️", benefit: "Safety organizing builds community resilience" },
    { title: "Launch Awareness Campaign", description: "Educate others about important issues", icon: "📢", benefit: "Awareness campaigns create knowledge and change" },
    { title: "Create Maker Space", description: "Build community workshop for creativity", icon: "🔧", benefit: "Maker spaces democratize tools and skills" },
    { title: "Organize Cultural Event", description: "Celebrate diversity and arts in community", icon: "🎭", benefit: "Cultural events build appreciation and unity" },
    { title: "Start Environmental Initiative", description: "Lead sustainability effort in your area", icon: "🌍", benefit: "Environmental leadership creates lasting positive impact" },
    { title: "Create Innovation Lab", description: "Build space for experimentation and invention", icon: "⚗️", benefit: "Innovation labs accelerate creative problem-solving" },
    
    // Adventure & Challenge
    { title: "Plan an Adventure", description: "Research and plan something exciting for the future", icon: "🗺️", benefit: "Anticipation extends happiness and gives purpose" },
    { title: "Try Something New", description: "Take on a new challenge or adventure", icon: "⭐", benefit: "New experiences create lasting positive memories" },
    { title: "Travel Solo", description: "Take independent trip to new destination", icon: "🎒", benefit: "Solo travel builds independence and confidence" },
    { title: "Climb a Mountain", description: "Set goal to reach a peak", icon: "⛰️", benefit: "Mountain climbing provides ultimate challenge and accomplishment" },
    { title: "Learn Extreme Sport", description: "Try activities that push your limits", icon: "🏂", benefit: "Extreme sports build courage and create peak experiences" },
    { title: "Take Wilderness Survival Course", description: "Learn to thrive in natural environments", icon: "🏕️", benefit: "Survival skills build confidence and connection to nature" },
    { title: "Cross Country Road Trip", description: "Drive across large distances to see country", icon: "🚗", benefit: "Road trips provide freedom and discovery" },
    { title: "Try International Travel", description: "Experience completely different cultures", icon: "✈️", benefit: "International travel builds perspective and tolerance" },
    { title: "Learn to Fly", description: "Get pilot's license or try flight lessons", icon: "✈️", benefit: "Flying provides ultimate freedom and perspective" },
    { title: "Try Scuba Diving", description: "Explore underwater worlds", icon: "🤿", benefit: "Diving reveals hidden beauty and builds adventure skills" },
    { title: "Go on Safari", description: "Experience wildlife in natural habitat", icon: "🦁", benefit: "Wildlife experiences create awe and environmental appreciation" },
    { title: "Try Ice Climbing", description: "Scale frozen waterfalls and cliffs", icon: "🧊", benefit: "Ice climbing provides extreme challenge and beauty" },
    { title: "Go Spelunking", description: "Explore caves and underground systems", icon: "🕳️", benefit: "Cave exploration reveals hidden natural wonders" },
    { title: "Try Hang Gliding", description: "Soar through the air with minimal equipment", icon: "🪂", benefit: "Hang gliding provides bird-like freedom" },
    { title: "Go Deep Sea Fishing", description: "Challenge yourself against large ocean fish", icon: "🎣", benefit: "Deep sea fishing provides adventure and skill challenge" },
    { title: "Try Helicopter Tours", description: "See landscapes from aerial perspective", icon: "🚁", benefit: "Helicopter tours provide unique perspectives" },
    { title: "Go Storm Chasing", description: "Safely observe severe weather phenomena", icon: "⛈️", benefit: "Storm chasing provides awe-inspiring natural experiences" },
    { title: "Try Hot Air Ballooning", description: "Float peacefully above the landscape", icon: "🎈", benefit: "Ballooning provides serene aerial adventure" },
    { title: "Go Volcano Hiking", description: "Safely explore volcanic landscapes", icon: "🌋", benefit: "Volcanic exploration reveals Earth's raw power" },
    { title: "Try Glacier Walking", description: "Explore ice formations with proper equipment", icon: "🧊", benefit: "Glacier exploration provides otherworldly experiences" },
    
    // Social & Community
    { title: "Connect with Loved Ones", description: "Organize a gathering or reach out to multiple friends", icon: "👥", benefit: "Sharing good vibes multiplies happiness" },
    { title: "Host a Party", description: "Bring people together for celebration", icon: "🎉", benefit: "Parties create joy and strengthen relationships" },
    { title: "Organize Group Adventure", description: "Plan exciting activity for friends", icon: "🗺️", benefit: "Group adventures build memories and bonds" },
    { title: "Start Social Club", description: "Create regular gathering around shared interest", icon: "🎯", benefit: "Social clubs build lasting friendships" },
    { title: "Plan Wedding or Celebration", description: "Organize meaningful life event", icon: "💒", benefit: "Celebrations mark important life transitions" },
    { title: "Create Family Reunion", description: "Bring extended family together", icon: "👨‍👩‍👧‍👦", benefit: "Family gatherings strengthen generational bonds" },
    { title: "Organize Surprise Party", description: "Create joy for someone special", icon: "🎁", benefit: "Surprises create memorable experiences for others" },
    { title: "Host Game Tournament", description: "Organize competitive fun with friends", icon: "🏆", benefit: "Tournaments combine competition with social fun" },
    { title: "Plan Group Travel", description: "Coordinate trip with friends or family", icon: "✈️", benefit: "Group travel creates shared adventures" },
    { title: "Create Flash Mob", description: "Organize spontaneous public performance", icon: "💃", benefit: "Flash mobs create public joy and connection" },
    { title: "Start Dinner Club", description: "Regular gatherings around food and conversation", icon: "🍽️", benefit: "Dinner clubs combine social connection with culinary exploration" },
    { title: "Organize Charity Event", description: "Bring people together for good cause", icon: "❤️", benefit: "Charity events create purpose and community impact" },
    { title: "Create Art Show", description: "Display work of local artists", icon: "🎨", benefit: "Art shows celebrate creativity and build cultural community" },
    { title: "Host Networking Event", description: "Connect professionals in your field", icon: "💼", benefit: "Networking events build professional community" },
    { title: "Plan Festival", description: "Organize celebration of culture or interest", icon: "🎪", benefit: "Festivals create lasting community traditions" },
    { title: "Create Speaker Series", description: "Bring interesting people to share knowledge", icon: "🎤", benefit: "Speaker series educate and inspire community" },
    { title: "Organize Sports League", description: "Create regular athletic competition", icon: "⚽", benefit: "Sports leagues build fitness and friendship" },
    { title: "Host Talent Show", description: "Showcase diverse abilities in your community", icon: "🎭", benefit: "Talent shows celebrate individual gifts" },
    { title: "Create Book Festival", description: "Celebrate literature and reading", icon: "📚", benefit: "Book festivals promote literacy and learning" },
    { title: "Organize Dance Event", description: "Create space for movement and music", icon: "💃", benefit: "Dance events promote joy and physical expression" },
    
    // Innovation & Entrepreneurship
    { title: "Patent an Invention", description: "Protect and commercialize your ideas", icon: "💡", benefit: "Patents create intellectual property and potential income" },
    { title: "Start Tech Company", description: "Build scalable technology business", icon: "💻", benefit: "Tech companies can create massive impact and value" },
    { title: "Create Subscription Service", description: "Build recurring value for customers", icon: "📦", benefit: "Subscriptions create predictable business models" },
    { title: "Launch Kickstarter Campaign", description: "Crowdfund your innovative project", icon: "💰", benefit: "Crowdfunding validates ideas and builds audience" },
    { title: "Build Franchise System", description: "Scale successful business model", icon: "🏪", benefit: "Franchising multiplies business impact" },
    { title: "Create Investment Fund", description: "Pool money to invest in other ventures", icon: "📈", benefit: "Investment funds create wealth and support other entrepreneurs" },
    { title: "Start Consulting Firm", description: "Monetize your expertise", icon: "🤝", benefit: "Consulting provides high-value service and flexibility" },
    { title: "Build Manufacturing Business", description: "Create physical products at scale", icon: "🏭", benefit: "Manufacturing creates jobs and tangible value" },
    { title: "Launch Import/Export Business", description: "Connect global markets", icon: "🌍", benefit: "Trade businesses create global connections" },
    { title: "Create Real Estate Empire", description: "Build wealth through property investment", icon: "🏘️", benefit: "Real estate provides passive income and wealth building" },
    { title: "Start Media Company", description: "Create content and information business", icon: "📺", benefit: "Media companies shape culture and opinion" },
    { title: "Build Software Platform", description: "Create tools other businesses use", icon: "⚙️", benefit: "Platforms enable others while creating recurring revenue" },
    { title: "Launch Food Business", description: "Start restaurant, catering, or food production", icon: "🍔", benefit: "Food businesses serve basic human needs" },
    { title: "Create Healthcare Innovation", description: "Improve medical services or devices", icon: "🏥", benefit: "Healthcare innovation saves lives and reduces suffering" },
    { title: "Start Education Company", description: "Create learning solutions for others", icon: "🎓", benefit: "Education businesses improve human potential" },
    { title: "Build Renewable Energy Business", description: "Create sustainable energy solutions", icon: "☀️", benefit: "Clean energy businesses help save the planet" },
    { title: "Launch Fashion Brand", description: "Create clothing or accessories business", icon: "👗", benefit: "Fashion brands create identity and self-expression" },
    { title: "Start Gaming Company", description: "Create entertainment through games", icon: "🎮", benefit: "Gaming creates joy and social connection" },
    { title: "Build Transportation Service", description: "Move people or goods efficiently", icon: "🚚", benefit: "Transportation enables commerce and connection" },
    { title: "Create Financial Services", description: "Help others manage money and invest", icon: "💳", benefit: "Financial services enable wealth building for others" },
    
    // Extreme Learning & Mastery
    { title: "Master a Skill", description: "Commit to achieving expert level in something", icon: "🎯", benefit: "Mastery provides deep satisfaction and accomplishment" },
    { title: "Learn Multiple Languages", description: "Become multilingual to connect globally", icon: "🌍", benefit: "Languages open doors to other cultures and opportunities" },
    { title: "Get Advanced Degree", description: "Pursue graduate education in field of interest", icon: "🎓", benefit: "Advanced education opens career and intellectual opportunities" },
    { title: "Become Expert Speaker", description: "Master public speaking and presentation", icon: "🎤", benefit: "Speaking expertise amplifies your influence" },
    { title: "Learn Professional Skills", description: "Master skills that advance your career", icon: "💼", benefit: "Professional mastery increases earning potential" },
    { title: "Develop Artistic Mastery", description: "Achieve expert level in creative field", icon: "🎨", benefit: "Artistic mastery provides lifelong creative satisfaction" },
    { title: "Master Athletic Skill", description: "Achieve expert level in sport or fitness", icon: "🏆", benefit: "Athletic mastery builds confidence and physical capability" },
    { title: "Learn Advanced Technology", description: "Master cutting-edge technical skills", icon: "🤖", benefit: "Technology mastery positions you for future opportunities" },
    { title: "Study Advanced Science", description: "Dive deep into scientific understanding", icon: "🔬", benefit: "Scientific knowledge provides understanding of reality" },
    { title: "Master Musical Instrument", description: "Achieve virtuoso level in music", icon: "🎹", benefit: "Musical mastery provides lifelong joy and expression" },
    { title: "Learn Advanced Mathematics", description: "Master complex mathematical concepts", icon: "📊", benefit: "Mathematical mastery improves analytical thinking" },
    { title: "Develop Leadership Expertise", description: "Master skills of influence and inspiration", icon: "👑", benefit: "Leadership mastery amplifies your impact on others" },
    { title: "Master Communication", description: "Become expert in written and verbal expression", icon: "📝", benefit: "Communication mastery improves all relationships" },
    { title: "Learn Investment Mastery", description: "Master wealth-building through investments", icon: "💰", benefit: "Investment mastery creates financial freedom" },
    { title: "Develop Teaching Expertise", description: "Master the art and science of education", icon: "👨‍🏫", benefit: "Teaching mastery helps others while reinforcing your own learning" },
    { title: "Master Problem-Solving", description: "Become expert at finding solutions", icon: "🧩", benefit: "Problem-solving mastery makes you valuable in any field" },
    { title: "Learn Sales Mastery", description: "Master the art of persuasion and influence", icon: "📈", benefit: "Sales mastery opens doors and creates opportunities" },
    { title: "Develop Design Expertise", description: "Master visual and functional design", icon: "🎨", benefit: "Design mastery combines aesthetics with functionality" },
    { title: "Master Time Management", description: "Optimize your productivity and efficiency", icon: "⏰", benefit: "Time mastery multiplies your effectiveness" },
    { title: "Learn Negotiation Mastery", description: "Master the art of mutual benefit", icon: "🤝", benefit: "Negotiation mastery improves all life outcomes" }
  ]
};

interface ActivitySuggestionsProps {
  moodValue: number;
  dayRating: number;
  onSkip: () => void;
  onBack: () => void;
  onComplete: (activity: {title: string; description: string; icon: string}) => void;
  favorites: {title: string; description: string; icon: string; benefit: string}[];
  onToggleFavorite: (activity: {title: string; description: string; icon: string; benefit: string}) => void;
  onViewAnalytics: () => void;
  onViewMemories: () => void;
  onViewFavorites: () => void;
  onViewFAQ?: () => void;
}

export function ActivitySuggestions({ moodValue, dayRating, onSkip, onBack, onComplete, favorites, onToggleFavorite, onViewAnalytics, onViewMemories, onViewFavorites, onViewFAQ }: ActivitySuggestionsProps) {
  const [selectedActivity, setSelectedActivity] = useState<number | null>(null);
  const [sidebarOpen, setSidebarOpen] = useState(false);

  // Determine mood category
  const getMoodCategory = (mood: number): 'low' | 'medium' | 'high' => {
    if (mood <= 4) return 'low';
    if (mood <= 7) return 'medium';
    return 'high';
  };

  const moodCategory = getMoodCategory(moodValue);
  const availableActivities = moodBasedActivities[moodCategory];
  
  // Randomly select 3 activities from the appropriate category
  const [suggestedActivities, setSuggestedActivities] = useState(() => {
    const shuffled = [...availableActivities].sort(() => Math.random() - 0.5);
    return shuffled.slice(0, 3);
  });

  const generateNewIdeas = () => {
    const shuffled = [...availableActivities].sort(() => Math.random() - 0.5);
    setSuggestedActivities(shuffled.slice(0, 3));
    setSelectedActivity(null); // Reset selection when getting new ideas
  };

  const handleActivitySelect = (index: number) => {
    setSelectedActivity(index);
  };

  const handleComplete = () => {
    if (selectedActivity !== null) {
      // Pass the selected activity to the parent
      onComplete(suggestedActivities[selectedActivity]);
    }
  };

  const getMoodTitle = (mood: number): string => {
    if (mood <= 4) return "Let's start with gentle activities";
    if (mood <= 7) return "Here are some uplifting activities";
    return "Channel that great energy into action";
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center p-4">
      <div className="w-full max-w-lg mx-auto">
        <div className="bg-card rounded-2xl shadow-lg border p-8 space-y-6 relative">
          {/* Navigation Menu */}
          <NavigationMenu
            sidebarOpen={sidebarOpen}
            setSidebarOpen={setSidebarOpen}
            onViewAnalytics={onViewAnalytics}
            onViewMemories={onViewMemories}
            onViewFavorites={onViewFavorites}
            onViewFAQ={onViewFAQ}
            currentPage="activities"
          />
          
          {/* Back Button */}
          <button
            onClick={onBack}
            className="flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors"
          >
            <ArrowLeft className="h-4 w-4" />
            <span className="text-sm">Back to Journal</span>
          </button>

          {/* Header */}
          <div className="text-center space-y-2">
            <h1 className="text-2xl">Boost Your Mood</h1>
            <p className="text-sm text-muted-foreground">
              {getMoodTitle(moodValue)}
            </p>
          </div>

          {/* Activity suggestions */}
          <div className="space-y-4">
            <div className="flex items-center justify-center gap-2 mb-4">
              <h3 className="text-center text-muted-foreground">
                Choose an activity that resonates with you:
              </h3>
              <FeatureExplainer 
                title="Activity Suggestions"
                description="These activities are personalized based on your current mood. Each suggestion is designed to help improve or maintain your well-being. You can save favorites to revisit later."
              />
            </div>
            
            {suggestedActivities.map((activity, index) => {
              const isFavorite = favorites.some(fav => fav.title === activity.title);
              
              return (
                <div
                  key={index}
                  className={`relative w-full p-4 rounded-lg border-2 transition-all duration-200 text-left ${
                    selectedActivity === index
                      ? 'border-primary bg-primary/10 shadow-md'
                      : 'border-border hover:border-primary/50'
                  }`}
                >
                  <button
                    onClick={() => handleActivitySelect(index)}
                    className="w-full text-left"
                  >
                    <div className="flex items-start gap-4">
                      <div className="text-3xl flex-shrink-0 mt-1">
                        {activity.icon}
                      </div>
                      <div className="flex-1 space-y-1 pr-8">
                        <h4 className={`font-medium ${
                          selectedActivity === index ? 'text-primary' : 'text-foreground'
                        }`}>
                          {activity.title}
                        </h4>
                        <p className="text-sm text-muted-foreground">
                          {activity.description}
                        </p>
                        <p className="text-xs text-muted-foreground italic">
                          💡 {activity.benefit}
                        </p>
                      </div>
                    </div>
                  </button>
                  
                  {/* Favorite button */}
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onToggleFavorite(activity);
                    }}
                    className="absolute top-4 right-4 p-2 rounded-lg hover:bg-background/80 transition-colors group"
                    aria-label={isFavorite ? "Remove from favorites" : "Add to favorites"}
                  >
                    <Heart 
                      className={`h-5 w-5 transition-all group-hover:scale-110 ${
                        isFavorite 
                          ? 'fill-red-500 text-red-500' 
                          : 'text-muted-foreground group-hover:text-red-500'
                      }`}
                    />
                  </button>
                </div>
              );
            })}
          </div>

          {/* Selected activity confirmation */}
          {selectedActivity !== null && (
            <div className="bg-secondary/50 rounded-lg p-4 text-center">
              <p className="text-sm text-muted-foreground">
                Great choice! <span className="text-foreground font-medium">
                  {suggestedActivities[selectedActivity].title}
                </span> can really help boost your mood.
              </p>
            </div>
          )}

          {/* Give me new ideas button */}
          <div className="flex justify-center pt-2">
            <button 
              className="bg-muted text-muted-foreground py-2 px-4 rounded-lg hover:bg-muted/80 transition-colors text-sm"
              onClick={generateNewIdeas}
            >
              Give me new ideas
            </button>
          </div>

          {/* Action buttons */}
          <div className="flex gap-3 pt-4">
            <button 
              className="flex-1 bg-secondary text-secondary-foreground py-3 px-6 rounded-lg hover:opacity-90 transition-opacity"
              onClick={onSkip}
            >
              Skip for Now
            </button>
            <button 
              className={`flex-1 py-3 px-6 rounded-lg transition-all ${
                selectedActivity !== null
                  ? 'bg-primary text-primary-foreground hover:opacity-90'
                  : 'bg-secondary text-secondary-foreground opacity-50 cursor-not-allowed'
              }`}
              onClick={handleComplete}
              disabled={selectedActivity === null}
            >
              I'll Do This
            </button>
          </div>

          {/* Footer message */}
          <div className="text-center pt-4 border-t">
            <p className="text-sm text-muted-foreground">
              Small actions can make a big difference in how you feel.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}