import React, { useState } from 'react';
import { ArrowLeft, Trash2, Heart } from 'lucide-react';
import { NavigationMenu } from './NavigationMenu';

interface Activity {
  title: string;
  description: string;
  icon: string;
  benefit: string;
}

interface FavoriteActivitiesProps {
  favorites: Activity[];
  onRemoveFavorite: (title: string) => void;
  onBackToHome: () => void;
  onViewAnalytics: () => void;
  onViewMemories: () => void;
  onViewFAQ?: () => void;
}

export function FavoriteActivities({ favorites, onRemoveFavorite, onBackToHome, onViewAnalytics, onViewMemories, onViewFAQ }: FavoriteActivitiesProps) {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center p-4">
      <div className="w-full max-w-3xl mx-auto">
        <div className="bg-card rounded-2xl shadow-lg border p-8 space-y-6 relative">
          {/* Navigation Menu */}
          <NavigationMenu
            sidebarOpen={sidebarOpen}
            setSidebarOpen={setSidebarOpen}
            onViewAnalytics={onViewAnalytics}
            onViewMemories={onViewMemories}
            onViewFavorites={() => {}} // Already on favorites
            onViewFAQ={onViewFAQ}
            currentPage="favorites"
          />
          
          {/* Back Button */}
          <button
            onClick={onBackToHome}
            className="flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors"
          >
            <ArrowLeft className="h-4 w-4" />
            <span className="text-sm">Back to Home</span>
          </button>

          {/* Header */}
          <div className="text-center space-y-2">
            <div className="flex items-center justify-center gap-2">
              <Heart className="h-6 w-6 text-red-500 fill-red-500" />
              <h1 className="text-2xl">Saved Favourite Activities</h1>
            </div>
            <p className="text-sm text-muted-foreground">
              Your collection of activities that bring you joy
            </p>
          </div>

          {/* Favorites list */}
          <div className="space-y-4">
            {favorites.length === 0 ? (
              <div className="text-center py-12 space-y-4">
                <div className="text-6xl opacity-50">💝</div>
                <div className="space-y-2">
                  <h3 className="text-muted-foreground">No favorites yet</h3>
                  <p className="text-sm text-muted-foreground">
                    When you find activities you love, click the heart icon to save them here!
                  </p>
                </div>
              </div>
            ) : (
              <>
                <div className="text-center mb-4">
                  <p className="text-sm text-muted-foreground">
                    You have {favorites.length} saved {favorites.length === 1 ? 'activity' : 'activities'}
                  </p>
                </div>
                
                <div className="grid gap-4">
                  {favorites.map((activity, index) => (
                    <div
                      key={index}
                      className="p-4 rounded-lg border-2 border-border bg-background shadow-sm"
                    >
                      <div className="flex items-start gap-4">
                        <div className="text-3xl flex-shrink-0 mt-1">
                          {activity.icon}
                        </div>
                        <div className="flex-1 space-y-1">
                          <h4 className="font-medium text-foreground">
                            {activity.title}
                          </h4>
                          <p className="text-sm text-muted-foreground">
                            {activity.description}
                          </p>
                          <p className="text-xs text-muted-foreground italic">
                            💡 {activity.benefit}
                          </p>
                        </div>
                        <button
                          onClick={() => onRemoveFavorite(activity.title)}
                          className="flex-shrink-0 p-2 rounded-lg hover:bg-destructive/10 text-destructive transition-colors group"
                          aria-label="Remove from favorites"
                        >
                          <Trash2 className="h-5 w-5 group-hover:scale-110 transition-transform" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </>
            )}
          </div>

          {/* Footer message */}
          {favorites.length > 0 && (
            <div className="text-center pt-4 border-t">
              <p className="text-sm text-muted-foreground">
                These activities are here whenever you need inspiration! 💝
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
