import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from './ui/dialog';
import { X, ChevronLeft, ChevronRight } from 'lucide-react';

interface TutorialProps {
  isOpen: boolean;
  onClose: () => void;
}

const tutorialSteps = [
  {
    title: "Welcome to MindScape! 🌟",
    description: "Your personal space for tracking moods, reflecting on your day, and discovering activities that lift your spirits.",
    content: "Let's take a quick tour to help you get started on your wellness journey."
  },
  {
    title: "Track Your Mood & Day 😊",
    description: "Start by selecting how you're feeling today using the emoji slider (1-10) and rate your overall day (1-5).",
    content: "Both selections are required before you can record your day. This helps you build awareness of your emotional patterns over time."
  },
  {
    title: "Journal Reflections 📝",
    description: "After recording your mood, you'll receive a thoughtful prompt from our collection of over 1,000 diverse questions.",
    content: "Take time to write your thoughts and feelings. This practice can help you process emotions and gain insights about yourself."
  },
  {
    title: "Activity Suggestions 🎯",
    description: "Based on your mood, we'll suggest three personalized activities to help improve or maintain your well-being.",
    content: "You can choose an activity, save favorites for later, or skip to analytics. Each suggestion is tailored to your current emotional state."
  },
  {
    title: "Capture Memories 📸",
    description: "After selecting an activity, you can optionally upload a photo to remember the moment.",
    content: "These photos become part of your memory collection, helping you recall positive experiences."
  },
  {
    title: "View Analytics 📊",
    description: "Track your mood trends over time with interactive charts and a calendar view.",
    content: "See patterns in your emotional well-being, view your journal entries, and gain insights into what affects your mood."
  },
  {
    title: "Access Your Content 🗂️",
    description: "Use the hamburger menu (☰) in the top right to navigate between Analytics, Memories, Saved Favorites, and FAQ.",
    content: "All your data is stored locally in your browser - private and secure."
  },
  {
    title: "You're All Set! 🎉",
    description: "You're ready to begin your MindScape journey. Remember, there's no right or wrong way to track your mood.",
    content: "Be honest with yourself, take your time with reflections, and use this tool in whatever way serves you best."
  }
];

export function Tutorial({ isOpen, onClose }: TutorialProps) {
  const [currentStep, setCurrentStep] = useState(0);

  const handleNext = () => {
    if (currentStep < tutorialSteps.length - 1) {
      setCurrentStep(currentStep + 1);
    }
  };

  const handlePrevious = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
    }
  };

  const handleFinish = () => {
    setCurrentStep(0);
    onClose();
  };

  const currentStepData = tutorialSteps[currentStep];

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle className="text-2xl text-center">{currentStepData.title}</DialogTitle>
          <DialogDescription className="text-center pt-2">
            {currentStepData.description}
          </DialogDescription>
        </DialogHeader>

        <div className="py-6">
          <p className="text-center text-muted-foreground">
            {currentStepData.content}
          </p>
        </div>

        {/* Progress indicator */}
        <div className="flex justify-center gap-2 pb-4">
          {tutorialSteps.map((_, index) => (
            <div
              key={index}
              className={`h-2 w-2 rounded-full transition-colors ${
                index === currentStep ? 'bg-primary' : 'bg-secondary'
              }`}
            />
          ))}
        </div>

        {/* Navigation buttons */}
        <div className="flex justify-between items-center pt-4 border-t">
          <button
            onClick={handlePrevious}
            disabled={currentStep === 0}
            className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors disabled:opacity-30 disabled:cursor-not-allowed"
          >
            <ChevronLeft className="h-4 w-4" />
            Previous
          </button>

          <span className="text-sm text-muted-foreground">
            {currentStep + 1} / {tutorialSteps.length}
          </span>

          {currentStep < tutorialSteps.length - 1 ? (
            <button
              onClick={handleNext}
              className="flex items-center gap-2 text-sm bg-primary text-primary-foreground px-4 py-2 rounded-lg hover:opacity-90 transition-opacity"
            >
              Next
              <ChevronRight className="h-4 w-4" />
            </button>
          ) : (
            <button
              onClick={handleFinish}
              className="text-sm bg-primary text-primary-foreground px-4 py-2 rounded-lg hover:opacity-90 transition-opacity"
            >
              Get Started!
            </button>
          )}
        </div>

        {/* Skip tutorial option */}
        <div className="text-center pt-2">
          <button
            onClick={handleFinish}
            className="text-xs text-muted-foreground hover:text-foreground transition-colors"
          >
            Skip tutorial
          </button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
