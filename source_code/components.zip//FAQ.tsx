import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from './ui/accordion';
import { ArrowLeft } from 'lucide-react';
import { NavigationMenu } from './NavigationMenu';

interface FAQProps {
  onBackToHome: () => void;
  onViewAnalytics: () => void;
  onViewMemories: () => void;
  onViewFavorites: () => void;
}

export function FAQ({ onBackToHome, onViewAnalytics, onViewMemories, onViewFavorites }: FAQProps) {
  const [sidebarOpen, setSidebarOpen] = React.useState(false);

  const faqs = [
    {
      question: "How does the mood tracking work?",
      answer: "MindScape uses an interactive emoji slider that lets you rate your mood on a scale of 1-10, from very sad 😢 to amazing 🤩. You also rate your overall day from 1-5. Both ratings are recorded together when you click 'Record My Day'."
    },
    {
      question: "What are journal prompts?",
      answer: "After tracking your mood, you'll receive a thoughtful prompt to reflect on your day. We have over 1,000 diverse prompts designed to help you explore your feelings and experiences. Your responses are saved in your Memories."
    },
    {
      question: "How do activity suggestions work?",
      answer: "Based on your mood rating, MindScape provides three mood-appropriate activity recommendations. You can choose any activity that resonates with you, and optionally upload a photo after completing it."
    },
    {
      question: "What can I see in Analytics?",
      answer: "The Analytics page shows your mood trends over time with interactive charts, your current tracking streak, best and worst days, activity completion rates, a word cloud from your journal entries, and an interactive calendar showing all your logged entries."
    },
    {
      question: "How do I access my past entries?",
      answer: "Click on the hamburger menu (☰) in the top right corner and select 'Memories'. You can view all your past entries in a calendar format. Click on any date to see your mood, journal entry, and activity photo from that day."
    },
    {
      question: "What are Saved Favourites?",
      answer: "You can save your favorite activities from the suggestions. Access them through the hamburger menu under 'Saved Favourites'. These activities are personalized to you and can be referenced anytime."
    },
    {
      question: "Can I reset my mood and day rating?",
      answer: "Yes! The main mood tracker page has a 'Reset' button that clears both your mood slider and day rating selections, allowing you to start fresh."
    },
    {
      question: "How is the word cloud generated?",
      answer: "The word cloud on the Analytics page extracts key words from your 10 most recent journal entries, showing you the most common themes and feelings in your reflections."
    },
    {
      question: "Is my data saved?",
      answer: "Currently, MindScape stores your data locally in your browser. Your entries, photos, and preferences are saved and will be available when you return to the app."
    },
    {
      question: "Can I track multiple times per day?",
      answer: "MindScape is designed for daily tracking, with one entry per day. This helps you build a consistent habit and makes it easier to track patterns over time."
    }
  ];

  return (
    <div className="min-h-screen p-8 bg-gradient-to-br from-blue-100 via-purple-50 to-pink-100">
      <NavigationMenu
        sidebarOpen={sidebarOpen}
        setSidebarOpen={setSidebarOpen}
        onViewAnalytics={onViewAnalytics}
        onViewMemories={onViewMemories}
        onViewFavorites={onViewFavorites}
        currentPage="faq"
      />

      <div className="max-w-4xl mx-auto">
        <Card className="relative shadow-lg">
          <button
            onClick={onBackToHome}
            className="absolute top-6 left-6 p-2 hover:bg-secondary rounded-lg transition-colors"
            aria-label="Back to home"
          >
            <ArrowLeft className="h-5 w-5" />
          </button>

          <CardHeader className="text-center pt-16 pb-6">
            <CardTitle className="text-3xl">Frequently Asked Questions</CardTitle>
            <p className="text-muted-foreground mt-2">
              Everything you need to know about MindScape
            </p>
          </CardHeader>

          <CardContent className="px-8 pb-8">
            <Accordion type="single" collapsible className="w-full">
              {faqs.map((faq, index) => (
                <AccordionItem key={index} value={`item-${index}`}>
                  <AccordionTrigger>{faq.question}</AccordionTrigger>
                  <AccordionContent>
                    {faq.answer}
                  </AccordionContent>
                </AccordionItem>
              ))}
            </Accordion>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
