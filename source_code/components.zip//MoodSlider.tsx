import React, { useState } from 'react';
import { Slider } from './ui/slider';
import { FeatureExplainer } from './FeatureExplainer';

const moodEmojis = {
  1: '😢',
  2: '😞', 
  3: '😕',
  4: '😐',
  5: '😌',
  6: '🙂',
  7: '😊',
  8: '😄',
  9: '😆',
  10: '🤩'
};

const moodLabels = {
  1: 'Very Sad',
  2: 'Sad',
  3: 'Down',
  4: 'Neutral',
  5: 'Calm',
  6: 'Good',
  7: 'Happy',
  8: 'Very Happy',
  9: 'Excited',
  10: 'Amazing'
};

interface MoodSliderProps {
  value: number | null;
  onChange: (value: number) => void;
}

export function MoodSlider({ value, onChange }: MoodSliderProps) {
  const currentEmoji = value ? moodEmojis[value as keyof typeof moodEmojis] : '😐';
  const currentLabel = value ? moodLabels[value as keyof typeof moodLabels] : 'Select your mood';

  return (
    <div className="w-full max-w-md mx-auto space-y-6">
      {/* Current mood display */}
      <div className="text-center space-y-4">
        <div className="text-6xl" role="img" aria-label={currentLabel}>
          {currentEmoji}
        </div>
        <div className="space-y-1">
          <div className="flex items-center justify-center gap-2">
            <p className="text-muted-foreground">
              {value ? `Mood Level: ${value}/10` : 'No mood selected'}
            </p>
            <FeatureExplainer 
              title="Mood Tracking"
              description="Track your emotional state on a scale of 1-10. Regular mood tracking helps you identify patterns and understand what affects your well-being over time."
            />
          </div>
          <p className="text-lg">{currentLabel}</p>
        </div>
      </div>

      {/* Slider */}
      <div className="space-y-4">
        <Slider
          value={value ? [value] : [1]}
          onValueChange={(values) => values.length > 0 && onChange(values[0])}
          max={10}
          min={1}
          step={1}
          className="w-full"
        />
        
        {/* Emoji scale indicators */}
        <div className="flex justify-between text-sm">
          {Object.entries(moodEmojis).map(([moodValue, emoji]) => (
            <div 
              key={moodValue}
              className={`text-center transition-all duration-200 cursor-pointer ${
                parseInt(moodValue) === value 
                  ? 'scale-125 opacity-100' 
                  : 'opacity-60 hover:opacity-80'
              }`}
              onClick={() => onChange(parseInt(moodValue))}
            >
              <div className="text-lg" role="img" aria-label={moodLabels[parseInt(moodValue) as keyof typeof moodLabels]}>
                {emoji}
              </div>
              <div className="text-xs text-muted-foreground">{moodValue}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}