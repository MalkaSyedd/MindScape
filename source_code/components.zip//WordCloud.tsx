import React, { useMemo } from 'react';

interface WordCloudProps {
  journalEntries: string[];
}

// Common words to filter out
const stopWords = new Set([
  'the', 'a', 'an', 'and', 'or', 'but', 'in', 'on', 'at', 'to', 'for', 'of', 'with', 'by', 'from',
  'as', 'is', 'was', 'are', 'were', 'be', 'been', 'being', 'have', 'has', 'had', 'do', 'does', 'did',
  'will', 'would', 'could', 'should', 'may', 'might', 'can', 'this', 'that', 'these', 'those', 'i',
  'you', 'he', 'she', 'it', 'we', 'they', 'my', 'your', 'his', 'her', 'its', 'our', 'their', 'me',
  'him', 'them', 'what', 'which', 'who', 'when', 'where', 'why', 'how', 'all', 'each', 'every',
  'both', 'few', 'more', 'most', 'other', 'some', 'such', 'no', 'nor', 'not', 'only', 'own', 'same',
  'so', 'than', 'too', 'very', 'just', 'about', 'into', 'through', 'during', 'before', 'after',
  'above', 'below', 'up', 'down', 'out', 'off', 'over', 'under', 'again', 'further', 'then', 'once',
  'am', 'im', 'ive', 'dont', 'didnt', 'doesnt', 'wasnt', 'werent', 'isnt', 'arent', 'hasnt', 'havent',
  'hadnt', 'wont', 'wouldnt', 'couldnt', 'shouldnt', 'cant', 'cannot', 'got', 'get', 'getting',
  'thing', 'things', 'really', 'still', 'also', 'even', 'much', 'way', 'because', 'if', 'there',
]);

interface WordFrequency {
  word: string;
  count: number;
}

export function WordCloud({ journalEntries }: WordCloudProps) {
  const wordFrequencies = useMemo(() => {
    // Combine all journal entries
    const allText = journalEntries.join(' ').toLowerCase();
    
    // Extract words (only alphanumeric)
    const words = allText.match(/\b[a-z]{3,}\b/g) || [];
    
    // Count frequencies
    const frequencyMap = new Map<string, number>();
    words.forEach(word => {
      if (!stopWords.has(word)) {
        frequencyMap.set(word, (frequencyMap.get(word) || 0) + 1);
      }
    });
    
    // Convert to array and sort by frequency
    const sortedWords: WordFrequency[] = Array.from(frequencyMap.entries())
      .map(([word, count]) => ({ word, count }))
      .sort((a, b) => b.count - a.count)
      .slice(0, 10); // Top 10 words
    
    return sortedWords;
  }, [journalEntries]);

  // Uniform style for all words
  const getWordStyle = (word: WordFrequency, index: number): React.CSSProperties => {
    return {
      fontSize: '16px',
      color: 'hsl(var(--primary))',
      fontWeight: 500,
      opacity: 0.85,
      padding: '4px 8px',
      display: 'inline-block',
      margin: '4px',
      transition: 'all 0.2s ease',
      cursor: 'default',
      lineHeight: 1.2,
    };
  };

  if (wordFrequencies.length === 0) {
    return (
      <div className="text-center py-8 text-muted-foreground text-sm">
        No journal entries yet. Start writing to see your word cloud!
      </div>
    );
  }

  return (
    <div className="flex flex-wrap justify-center items-center p-4 min-h-[200px] gap-1">
      {wordFrequencies.map((word, index) => (
        <span
          key={`${word.word}-${index}`}
          style={getWordStyle(word, index)}
          className="hover:scale-110 select-none"
          title={`${word.word}: ${word.count} times`}
        >
          {word.word}
        </span>
      ))}
    </div>
  );
}
