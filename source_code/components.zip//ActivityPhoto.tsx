import React, { useState, useRef } from 'react';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { NavigationMenu } from './NavigationMenu';
import { FeatureExplainer } from './FeatureExplainer';

interface ActivityPhotoProps {
  selectedActivity: {
    title: string;
    description: string;
    icon: string;
  };
  onComplete: () => void;
  onViewAnalytics: () => void;
  onViewMemories: () => void;
  onViewFavorites: () => void;
  onViewFAQ?: () => void;
}

export function ActivityPhoto({ selectedActivity, onComplete, onViewAnalytics, onViewMemories, onViewFavorites, onViewFAQ }: ActivityPhotoProps) {
  const [uploadedImage, setUploadedImage] = useState<string | null>(null);
  const [isDragging, setIsDragging] = useState(false);
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileSelect = (file: File) => {
    if (file && file.type.startsWith('image/')) {
      const reader = new FileReader();
      reader.onload = (e) => {
        if (e.target?.result) {
          setUploadedImage(e.target.result as string);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    
    const files = Array.from(e.dataTransfer.files);
    if (files.length > 0) {
      handleFileSelect(files[0]);
    }
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  };

  const handleFileInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files && files.length > 0) {
      handleFileSelect(files[0]);
    }
  };

  const handleUploadClick = () => {
    fileInputRef.current?.click();
  };

  const handleRemoveImage = () => {
    setUploadedImage(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const handleSaveWithPhoto = () => {
    // In a real app, you would upload the photo to a server here
    onComplete();
  };

  const handleSkipPhoto = () => {
    onComplete();
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center p-4">
      <div className="w-full max-w-lg mx-auto">
        <div className="bg-card rounded-2xl shadow-lg border p-8 space-y-6 relative">
          {/* Navigation Menu */}
          <NavigationMenu
            sidebarOpen={sidebarOpen}
            setSidebarOpen={setSidebarOpen}
            onViewAnalytics={onViewAnalytics}
            onViewMemories={onViewMemories}
            onViewFavorites={onViewFavorites}
            onViewFAQ={onViewFAQ}
            currentPage="photo"
          />
          
          {/* Header */}
          <div className="text-center space-y-2">
            <div className="flex items-center justify-center gap-2">
              <h1 className="text-2xl">Capture the Moment</h1>
              <FeatureExplainer 
                title="Photo Upload (Optional)"
                description="Upload a photo to create a visual memory of your activity. These photos become part of your Memories collection, helping you recall positive experiences. This step is completely optional."
              />
            </div>
            <p className="text-sm text-muted-foreground">
              Upload a picture of you doing the activity for your memories
            </p>
          </div>

          {/* Selected activity reminder */}
          <div className="bg-secondary/50 rounded-lg p-4 text-center">
            <div className="flex items-center justify-center gap-3 mb-2">
              <span className="text-2xl">{selectedActivity.icon}</span>
              <span className="font-medium">{selectedActivity.title}</span>
            </div>
            <p className="text-sm text-muted-foreground">
              {selectedActivity.description}
            </p>
          </div>

          {/* Photo upload area */}
          <div className="space-y-4">
            {!uploadedImage ? (
              <div
                className={`border-2 border-dashed rounded-lg p-8 text-center transition-all duration-200 cursor-pointer ${
                  isDragging
                    ? 'border-primary bg-primary/10 scale-[1.02]'
                    : 'border-border hover:border-primary/50 hover:bg-secondary/30'
                }`}
                onDrop={handleDrop}
                onDragOver={handleDragOver}
                onDragLeave={handleDragLeave}
                onClick={handleUploadClick}
              >
                <div className="space-y-4">
                  <div className="text-4xl">📸</div>
                  <div className="space-y-2">
                    <h3 className="font-medium">Upload a photo</h3>
                    <p className="text-sm text-muted-foreground">
                      Drag and drop or click to select an image
                    </p>
                    <p className="text-xs text-muted-foreground">
                      JPG, PNG, or GIF up to 10MB
                    </p>
                  </div>
                </div>
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/*"
                  onChange={handleFileInputChange}
                  className="hidden"
                />
              </div>
            ) : (
              <div className="space-y-4">
                <div className="relative rounded-lg overflow-hidden bg-secondary/30 p-4">
                  <img
                    src={uploadedImage}
                    alt="Uploaded activity"
                    className="w-full h-48 object-cover rounded-lg"
                  />
                  <button
                    onClick={handleRemoveImage}
                    className="absolute top-2 right-2 bg-red-500 text-white rounded-full w-8 h-8 flex items-center justify-center hover:bg-red-600 transition-colors"
                  >
                    ×
                  </button>
                </div>
                <div className="text-center">
                  <p className="text-sm text-muted-foreground">
                    Great! Your photo looks awesome. You can upload a different one or continue.
                  </p>
                  <button
                    onClick={handleUploadClick}
                    className="text-sm text-primary hover:underline mt-2"
                  >
                    Choose a different photo
                  </button>
                </div>
              </div>
            )}
            
            {/* Upload Button */}
            <div className="flex justify-center">
              <button
                onClick={handleUploadClick}
                className="bg-primary text-primary-foreground py-2 px-6 rounded-lg hover:opacity-90 transition-opacity"
              >
                Upload Photo
              </button>
            </div>
          </div>



          {/* Action buttons */}
          <div className="flex gap-3 pt-4">
            <button 
              className="flex-1 bg-secondary text-secondary-foreground py-3 px-6 rounded-lg hover:opacity-90 transition-opacity"
              onClick={handleSkipPhoto}
            >
              Skip Photo
            </button>
            <button 
              className="flex-1 bg-primary text-primary-foreground py-3 px-6 rounded-lg hover:opacity-90 transition-opacity"
              onClick={handleSaveWithPhoto}
            >
              {uploadedImage ? 'Save with Photo' : 'Continue'}
            </button>
          </div>

          {/* Footer message */}
          <div className="text-center pt-4 border-t">
            <p className="text-sm text-muted-foreground">
              Photos help you remember and celebrate your progress!
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}