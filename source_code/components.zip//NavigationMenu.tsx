import React from 'react';
import { Sheet, SheetContent, SheetDescription, SheetHeader, SheetTitle, SheetTrigger } from './ui/sheet';
import { VisuallyHidden } from '@radix-ui/react-visually-hidden';
import { Menu } from 'lucide-react';

interface NavigationMenuProps {
  sidebarOpen: boolean;
  setSidebarOpen: (open: boolean) => void;
  onViewAnalytics: () => void;
  onViewMemories: () => void;
  onViewFavorites: () => void;
  onViewFAQ?: () => void;
  currentPage: 'mood-tracker' | 'journal' | 'activities' | 'photo' | 'analytics' | 'memories' | 'favorites' | 'faq';
}

export function NavigationMenu({
  sidebarOpen,
  setSidebarOpen,
  onViewAnalytics,
  onViewMemories,
  onViewFavorites,
  onViewFAQ,
  currentPage,
}: NavigationMenuProps) {
  const handleAnalyticsClick = () => {
    onViewAnalytics();
    setSidebarOpen(false);
  };

  const handleMemoriesClick = () => {
    onViewMemories();
    setSidebarOpen(false);
  };

  const handleFavoritesClick = () => {
    onViewFavorites();
    setSidebarOpen(false);
  };

  const handleFAQClick = () => {
    if (onViewFAQ) {
      onViewFAQ();
      setSidebarOpen(false);
    }
  };

  return (
    <div className="absolute top-4 right-4">
      <Sheet open={sidebarOpen} onOpenChange={setSidebarOpen}>
        <SheetTrigger asChild>
          <button className="p-2 rounded-lg bg-secondary hover:bg-secondary/80 transition-colors">
            <Menu className={`h-5 w-5 transition-colors ${sidebarOpen ? 'text-green-600' : ''}`} />
          </button>
        </SheetTrigger>
        <SheetContent side="right" className="w-80">
          <SheetHeader>
            <VisuallyHidden>
              <SheetTitle>Navigation Menu</SheetTitle>
            </VisuallyHidden>
            <VisuallyHidden>
              <SheetDescription>Navigate to different sections of the MindScape app</SheetDescription>
            </VisuallyHidden>
          </SheetHeader>
          <div className="mt-8">
            <h3 className="text-center mb-6" style={{ fontFamily: 'cursive' }}>
              MindScape Menu
            </h3>
            <div className="space-y-2">
              <button
                onClick={handleAnalyticsClick}
                className={`w-full text-center p-2 hover:opacity-70 transition-opacity text-lg rounded-lg ${
                  currentPage === 'analytics' ? 'bg-green-100 text-green-700' : ''
                }`}
              >
                View Analytics
              </button>
              <button
                onClick={handleMemoriesClick}
                className={`w-full text-center p-2 hover:opacity-70 transition-opacity text-lg rounded-lg ${
                  currentPage === 'memories' ? 'bg-green-100 text-green-700' : ''
                }`}
              >
                Memories
              </button>
              <button
                onClick={handleFavoritesClick}
                className={`w-full text-center p-2 hover:opacity-70 transition-opacity text-lg rounded-lg ${
                  currentPage === 'favorites' ? 'bg-green-100 text-green-700' : ''
                }`}
              >
                Saved Favourites
              </button>
              <button
                onClick={handleFAQClick}
                className={`w-full text-center p-2 hover:opacity-70 transition-opacity text-lg rounded-lg ${
                  currentPage === 'faq' ? 'bg-green-100 text-green-700' : ''
                }`}
              >
                FAQ
              </button>
            </div>
          </div>
        </SheetContent>
      </Sheet>
    </div>
  );
}
